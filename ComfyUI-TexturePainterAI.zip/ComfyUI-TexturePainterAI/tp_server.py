"""HTTP routes used by the web extension (model upload, session storage). Registered on import."""
import hashlib
import json
import os
import re
import time
import uuid

from aiohttp import web
from server import PromptServer

from . import tp_common as C
from . import tp_core as core

routes = PromptServer.instance.routes
VERSION = "1.0.0"

PNG_MAGIC = b"\x89PNG\r\n\x1a\n"
# multipart field -> file inside the session folder
PASS_PARTS = {"view": "view.png", "viewmask": "viewmask.png", "depth": "depth.png", "normal": "normal.png"}
STATE_PARTS = {"uvmask": "mask.png", "texture": "texture.png"}
MODEL_NAME_RE = re.compile(r"^[A-Za-z0-9._ -]{1,140}$")


def _json(data, status=200):
    return web.json_response(data, status=status, headers={"Cache-Control": "no-store"})


def _field_bytes(post, key):
    f = post.get(key)
    if f is None:
        return None
    if not hasattr(f, "file"):
        raise ValueError(f"Field '{key}' must be a file upload")
    return f.file.read()


def _store_parts(sdir, post, parts):
    written = []
    for key, fname in parts.items():
        data = _field_bytes(post, key)
        if data is None:
            continue
        if not data.startswith(PNG_MAGIC):
            raise ValueError(f"Field '{key}' is not a PNG image")
        C.atomic_write(os.path.join(sdir, fname), data)
        written.append(fname)
    return written


def _store_mesh(sdir, post):
    data = _field_bytes(post, "mesh")
    if data is None:
        return False
    core.read_mesh_bin(data)  # validates the container before it is stored
    C.atomic_write(os.path.join(sdir, "mesh.bin"), data)
    return True


@routes.get("/texpaint/ping")
async def ping(request):
    return _json({"ok": True, "version": VERSION, "dir": C.base_dir()})


@routes.post("/texpaint/upload_model")
async def upload_model(request):
    try:
        post = await request.post()
        f = post.get("file")
        if f is None or not hasattr(f, "file"):
            return _json({"error": "No file in the request"}, 400)
        stem, ext = C.safe_model_name(getattr(f, "filename", "model"))
        data = f.file.read()
        if not data:
            return _json({"error": "The uploaded file is empty"}, 400)
        name = f"{stem}_{hashlib.sha1(data).hexdigest()[:8]}{ext}"
        path = os.path.join(C.models_dir(), name)
        if not os.path.exists(path):
            C.atomic_write(path, data)
        return _json({"name": name, "size": len(data)})
    except ValueError as e:
        return _json({"error": str(e)}, 400)
    except Exception as e:
        C.log_exc("upload_model failed")
        return _json({"error": f"{type(e).__name__}: {e}"}, 500)


@routes.get("/texpaint/models")
async def list_models(request):
    try:
        d = C.models_dir()
        items = [(os.path.getmtime(os.path.join(d, n)), n) for n in os.listdir(d) if n.lower().endswith(C.MODEL_EXT)]
        items.sort(reverse=True)
        return _json({"models": [n for _, n in items[:60]]})
    except Exception as e:
        C.log_exc("list_models failed")
        return _json({"error": str(e)}, 500)


@routes.get("/texpaint/model/{name}")
async def get_model(request):
    name = request.match_info["name"]
    if not MODEL_NAME_RE.match(name) or not name.lower().endswith(C.MODEL_EXT):
        return _json({"error": "bad model name"}, 400)
    path = os.path.join(C.models_dir(), name)
    if not os.path.isfile(path):
        return _json({"error": "model not found"}, 404)
    return web.FileResponse(path, headers={"Cache-Control": "no-store"})


@routes.post("/texpaint/put/{sid}")
async def put_session(request):
    """Autosave: mask / texture / mesh / ui state. Never touches commit.json."""
    try:
        sdir = C.session_dir(request.match_info["sid"], create=True)
        post = await request.post()
        written = _store_parts(sdir, post, STATE_PARTS)
        if _store_mesh(sdir, post):
            written.append("mesh.bin")
        st = post.get("state")
        if isinstance(st, str):
            json.loads(st)
            C.atomic_write(os.path.join(sdir, "state.json"), st.encode("utf-8"))
            written.append("state.json")
        return _json({"ok": True, "written": written})
    except ValueError as e:
        return _json({"error": str(e)}, 400)
    except Exception as e:
        C.log_exc("put_session failed")
        return _json({"error": f"{type(e).__name__}: {e}"}, 500)


@routes.post("/texpaint/commit/{sid}")
async def commit_session(request):
    """Stores the passes captured by the editor and stamps commit.json (written last)."""
    try:
        sid = request.match_info["sid"]
        sdir = C.session_dir(sid, create=True)
        post = await request.post()
        written = _store_parts(sdir, post, PASS_PARTS) + _store_parts(sdir, post, STATE_PARTS)
        if _store_mesh(sdir, post):
            written.append("mesh.bin")
        meta = post.get("meta")
        if not isinstance(meta, str):
            return _json({"error": "missing 'meta' field"}, 400)
        meta_obj = json.loads(meta)
        for k in ("camera", "view_size", "mesh_hash"):
            if k not in meta_obj:
                return _json({"error": f"meta is missing '{k}'"}, 400)
        C.atomic_write(os.path.join(sdir, "camera.json"), meta.encode("utf-8"))
        written.append("camera.json")
        cid = post.get("commit_id")
        cid = cid if isinstance(cid, str) and C.SID_RE.match(cid) else uuid.uuid4().hex[:16]
        C.atomic_write(os.path.join(sdir, "commit.json"), json.dumps({"commit_id": cid, "time": time.time()}).encode("utf-8"))
        return _json({"ok": True, "commit_id": cid, "written": written})
    except ValueError as e:
        return _json({"error": str(e)}, 400)
    except Exception as e:
        C.log_exc("commit_session failed")
        return _json({"error": f"{type(e).__name__}: {e}"}, 500)


@routes.get("/texpaint/session/{sid}/{fname}")
async def get_session_file(request):
    try:
        sdir = C.session_dir(request.match_info["sid"])
    except ValueError:
        return _json({"error": "bad session id"}, 400)
    fname = request.match_info["fname"]
    if fname not in C.SESSION_FILES and not C.RESULT_RE.match(fname):
        return _json({"error": "file not allowed"}, 400)
    path = os.path.join(sdir, fname)
    if not os.path.isfile(path):
        return _json({"error": "not found"}, 404)
    return web.FileResponse(path, headers={"Cache-Control": "no-store"})


@routes.post("/texpaint/clone")
async def clone_session(request):
    """Copies the stored files of one session into another (used when a node is duplicated)."""
    try:
        body = await request.json()
        src = C.session_dir(body.get("src"))
        dst = C.session_dir(body.get("dst"), create=True)
        copied = []
        for fname in ("mesh.bin", "texture.png", "mask.png"):
            sp = os.path.join(src, fname)
            if os.path.isfile(sp):
                with open(sp, "rb") as f:
                    C.atomic_write(os.path.join(dst, fname), f.read())
                copied.append(fname)
        return _json({"ok": True, "copied": copied})
    except ValueError as e:
        return _json({"error": str(e)}, 400)
    except Exception as e:
        C.log_exc("clone_session failed")
        return _json({"error": f"{type(e).__name__}: {e}"}, 500)
