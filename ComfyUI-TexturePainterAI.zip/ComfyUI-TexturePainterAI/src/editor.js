// Texture Painter editor core: GL setup, scenes, projective mask painting, texture handling, capture.
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { parseModel, buildMerged, hashGeometry, serializeMesh, buildUVLines, extOf, SUPPORTED_EXT } from './meshio.js';
import * as SH from './shaders.js';
import { buildUI } from './ui.js';
import { installPanels } from './panels.js';

export const DEFAULT_STATE = () => ({
  v: 1,
  model: null,
  tool: 'brush',
  brush: { size: 70, hardness: 0.7, softness: 0.5, opacity: 1, spacing: 0.12, stab: 0.2 },
  erase: { size: 70, hardness: 0.7, softness: 0.5, opacity: 1, spacing: 0.12, stab: 0.2 },
  pen: true,
  mask: { show: true, opacity: 0.6, amount: 8 },
  capture: { aspect: '1:1', long: 1024, shading: 'unlit', bg: '#808080', facing: 0.25, frame: true },
  display: { layout: 'split', wire3d: false, shade3d: 0, uvWire: 0.35 },
  options: { clearMask: true, autoApply: false },
  camera: null,
});

function deepMerge(base, over) {
  if (!over || typeof over !== 'object') return base;
  for (const k of Object.keys(over)) {
    if (base[k] && typeof base[k] === 'object' && !Array.isArray(base[k]) && over[k] && typeof over[k] === 'object') deepMerge(base[k], over[k]);
    else if (over[k] !== undefined) base[k] = over[k];
  }
  return base;
}

const hexToRaw = (hex) => {
  const c = /^#?([0-9a-f]{6})$/i.exec(hex || '');
  const n = c ? parseInt(c[1], 16) : 0x808080;
  return [((n >> 16) & 255) / 255, ((n >> 8) & 255) / 255, (n & 255) / 255];
};

export class TexturePaintEditor {
  constructor({ hooks = {}, state = null } = {}) {
    this.hooks = hooks;
    this.state = deepMerge(DEFAULT_STATE(), state || {});
    this.ui = buildUI();
    this.root = this.ui.root;
    this.disposed = false;
    this.needsRender = true;
    this.hudDirty = true;
    this.logLines = [];
    this.undoStack = [];
    this.redoStack = [];
    this.texHistory = [];
    this.geometry = null;
    this.info = null;
    this.meshHash = null;
    this.textureVersion = 0;
    this.maskVersion = 0;
    this.spaceDown = false;
    this.stroke = null;
    this.hover = null;
    this.hoverUV = null;
    this.pending = null; // pending generation result
    this.compare = false;
    this.uvView = { cx: 0.5, cy: 0.5, zoom: 1 };
    this._emitTimer = 0;
    this._lastRay = 0;

    try {
      this._initGL();
      this._initScenes();
      this._initMask(2048);
      this._makeBlankTexture(2048, '#c8c8c8');
    } catch (e) {
      this.log('error', 'WebGL2 initialisation failed', e);
      this.setStatus('WebGL2 is required but could not be initialised: ' + (e && e.message), 'err');
      this.failed = true;
      return;
    }
    installPanels(this);
    this._applyStateToUI();
    this._startLoop();
  }

  // ----------------------------------------------------------------------------------------
  // logging / status
  // ----------------------------------------------------------------------------------------
  log(level, msg, err) {
    const t = new Date().toLocaleTimeString();
    let text = `[${t}] ${msg}`;
    if (err) text += '\n' + (err.stack || err.message || String(err));
    this.logLines.push(text);
    if (this.logLines.length > 300) this.logLines.shift();
    if (this.ui && this.ui.logEl) {
      const d = document.createElement('div');
      d.className = level === 'error' ? 'e' : level === 'warn' ? 'w' : level === 'ok' ? 'o' : '';
      d.textContent = text;
      this.ui.logEl.appendChild(d);
      while (this.ui.logEl.childNodes.length > 300) this.ui.logEl.removeChild(this.ui.logEl.firstChild);
      this.ui.logEl.scrollTop = this.ui.logEl.scrollHeight;
    }
    (level === 'error' ? console.error : level === 'warn' ? console.warn : console.log)('[TexturePainterAI]', msg, err || '');
  }

  setStatus(text, kind) {
    const m = this.ui.msg;
    m.textContent = text;
    m.className = 'tp-msg' + (kind ? ' tp-' + kind : '');
  }

  // ----------------------------------------------------------------------------------------
  // GL / scene setup
  // ----------------------------------------------------------------------------------------
  _initGL() {
    const canvas = this.ui.glCanvas;
    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: false, powerPreference: 'high-performance' });
    if (!this.renderer.capabilities.isWebGL2) throw new Error('WebGL2 not available');
    this.renderer.autoClear = false;
    this.dpr = Math.min(window.devicePixelRatio || 1, 2);
    this.renderer.setPixelRatio(this.dpr);
    this.maxAniso = Math.min(8, this.renderer.capabilities.getMaxAnisotropy());
    canvas.addEventListener('webglcontextlost', (e) => { e.preventDefault(); this.log('warn', 'WebGL context lost - the mask may need to be reloaded from the session.'); });
    canvas.addEventListener('webglcontextrestored', () => { this.log('warn', 'WebGL context restored.'); this.invalidate(); });
  }

  _initScenes() {
    // ---- 3D view
    this.scene = new THREE.Scene();
    this.camera = new THREE.PerspectiveCamera(40, 1, 0.02, 60);
    this.camera.position.set(0, 0.5, 3.4);
    this.controls = new OrbitControls(this.camera, this.ui.pane3d);
    this.controls.enableDamping = false;
    this.controls.screenSpacePanning = true;
    this.controls.zoomSpeed = 1.1;
    this.controls.addEventListener('change', () => { this.invalidate(); this._cameraTouched(); });
    this.grid = new THREE.GridHelper(4, 16, 0x3a3f4d, 0x262a33);
    this.grid.position.y = -1.02;
    this.scene.add(this.grid);

    this.meshMat = new THREE.ShaderMaterial({
      vertexShader: SH.MESH_VERT,
      fragmentShader: SH.MESH_FRAG,
      side: THREE.DoubleSide,
      uniforms: {
        tColor: { value: null },
        tMask: { value: null },
        uMaskColor: { value: new THREE.Vector3(1.0, 0.2, 0.85) },
        uMaskOpacity: { value: 0.6 },
        uShowMask: { value: 1 },
        uShade: { value: 0 },
        uFacingThr: { value: 0.25 },
      },
    });
    this.wireMat = new THREE.MeshBasicMaterial({ color: 0x8fd0ff, wireframe: true, transparent: true, opacity: 0.25, depthWrite: false });
    this.raycaster = new THREE.Raycaster();

    // ---- UV view
    this.uvScene = new THREE.Scene();
    this.uvCam = new THREE.OrthographicCamera(-1, 1, 1, -1, -10, 10);
    this.uvCam.position.set(0.5, 0.5, 5);
    this.uvMat = new THREE.ShaderMaterial({
      vertexShader: SH.UVQUAD_VERT,
      fragmentShader: SH.UVQUAD_FRAG,
      side: THREE.DoubleSide,
      uniforms: {
        tColor: { value: null },
        tMask: { value: null },
        uMaskColor: { value: new THREE.Vector3(1.0, 0.2, 0.85) },
        uMaskOpacity: { value: 0.6 },
        uShowMask: { value: 1 },
        uChecker: { value: 0 },
      },
    });
    const qg = new THREE.PlaneGeometry(1, 1);
    qg.translate(0.5, 0.5, 0);
    this.uvQuad = new THREE.Mesh(qg, this.uvMat);
    this.uvScene.add(this.uvQuad);
    this.uvLineMat = new THREE.LineBasicMaterial({ color: 0x74b0ff, transparent: true, opacity: 0.35, depthTest: false });
    // frame around the 0-1 square
    const frame = new THREE.LineLoop(
      new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(0, 0, 0.001), new THREE.Vector3(1, 0, 0.001), new THREE.Vector3(1, 1, 0.001), new THREE.Vector3(0, 1, 0.001)]),
      new THREE.LineBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.5, depthTest: false })
    );
    this.uvScene.add(frame);

    // ---- full-screen pass helpers
    this.quadScene = new THREE.Scene();
    this.quadCam = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);
    this.quad = new THREE.Mesh(new THREE.PlaneGeometry(2, 2), new THREE.MeshBasicMaterial());
    this.quad.frustumCulled = false;
    this.quadScene.add(this.quad);
    const passMat = (frag, extra = {}) => new THREE.ShaderMaterial({
      vertexShader: SH.FULLSCREEN_VERT, fragmentShader: frag, depthTest: false, depthWrite: false, blending: THREE.NoBlending,
      uniforms: { tSrc: { value: null }, ...extra },
    });
    this.copyMat = passMat(SH.COPY_FRAG);
    this.copyGreyMat = passMat(SH.COPY_GREY_FRAG);
    this.invertMat = passMat(SH.INVERT_FRAG);
    this.fillMat = passMat(SH.FILL_FRAG);
    this.morphMat = passMat(SH.MORPH_FRAG, { uStep: { value: new THREE.Vector2() }, uR: { value: 1 }, uMode: { value: 0 } });

    // ---- projective brush (draws the mesh into UV space)
    const paintUniforms = () => ({
      uVP: { value: new THREE.Matrix4() },
      uCam: { value: new THREE.Vector3() },
      uCenter: { value: new THREE.Vector2() },
      uSize: { value: new THREE.Vector2(1, 1) },
      uRadius: { value: 20 },
      uHardness: { value: 0.7 },
      uSoft: { value: 0.5 },
      uOpacity: { value: 1 },
      uDepth: { value: null },
      uNear: { value: 0.02 },
      uFar: { value: 60 },
      uBias: { value: 0.006 },
      uFacingMin: { value: 0.03 },
    });
    this.paintMat = new THREE.ShaderMaterial({
      vertexShader: SH.PAINT_VERT, fragmentShader: SH.PAINT_FRAG, side: THREE.DoubleSide, depthTest: false, depthWrite: false, transparent: true,
      blending: THREE.CustomBlending, blendEquation: THREE.MaxEquation, blendSrc: THREE.OneFactor, blendDst: THREE.OneFactor,
      blendEquationAlpha: THREE.MaxEquation, blendSrcAlpha: THREE.OneFactor, blendDstAlpha: THREE.OneFactor,
      uniforms: paintUniforms(),
    });
    this.eraseMat = new THREE.ShaderMaterial({
      vertexShader: SH.PAINT_VERT, fragmentShader: SH.PAINT_FRAG, side: THREE.DoubleSide, depthTest: false, depthWrite: false, transparent: true,
      blending: THREE.CustomBlending, blendEquation: THREE.AddEquation, blendSrc: THREE.ZeroFactor, blendDst: THREE.OneMinusSrcAlphaFactor,
      blendEquationAlpha: THREE.AddEquation, blendSrcAlpha: THREE.ZeroFactor, blendDstAlpha: THREE.OneMinusSrcAlphaFactor,
      uniforms: paintUniforms(),
    });
    this.paintScene = new THREE.Scene();
    this.depthMat = new THREE.ShaderMaterial({ vertexShader: SH.DEPTH_ONLY_VERT, fragmentShader: SH.DEPTH_ONLY_FRAG, side: THREE.DoubleSide });
    this.depthScene = new THREE.Scene();

    // ---- capture passes
    this.passMat = new THREE.ShaderMaterial({
      vertexShader: SH.PASS_VERT, fragmentShader: SH.PASS_FRAG, side: THREE.DoubleSide,
      uniforms: { tColor: { value: null }, tMask: { value: null }, uMode: { value: 0 }, uShade: { value: 0 }, uNear: { value: 0.1 }, uFar: { value: 10 } },
    });
    this.passScene = new THREE.Scene();
  }

  _initMask(size) {
    for (const k of ['maskRT', 'tmpRT', 'readRT']) if (this[k]) this[k].dispose();
    for (const s of this.undoStack.concat(this.redoStack)) s.dispose();
    this.undoStack = [];
    this.redoStack = [];
    this.maskSize = size;
    const mk = () => new THREE.WebGLRenderTarget(size, size, {
      format: THREE.RedFormat, type: THREE.UnsignedByteType, minFilter: THREE.LinearFilter, magFilter: THREE.LinearFilter,
      depthBuffer: false, stencilBuffer: false, generateMipmaps: false,
    });
    this.maskRT = mk();
    this.tmpRT = mk();
    this.readRT = new THREE.WebGLRenderTarget(size, size, { format: THREE.RGBAFormat, type: THREE.UnsignedByteType, depthBuffer: false, minFilter: THREE.NearestFilter, magFilter: THREE.NearestFilter, generateMipmaps: false });
    this._clearRT(this.maskRT, 0);
    this._bindMask();
  }

  _bindMask() {
    this.meshMat.uniforms.tMask.value = this.maskRT.texture;
    this.uvMat.uniforms.tMask.value = this.maskRT.texture;
    this.passMat.uniforms.tMask.value = this.maskRT.texture;
    this.invalidate();
  }

  // ----------------------------------------------------------------------------------------
  // render helpers
  // ----------------------------------------------------------------------------------------
  invalidate() { this.needsRender = true; this.hudDirty = true; }

  _clearRT(rt, v) {
    const r = this.renderer;
    const prevT = r.getRenderTarget();
    const prevC = new THREE.Color();
    r.getClearColor(prevC);
    const prevA = r.getClearAlpha();
    r.setRenderTarget(rt);
    r.setClearColor(new THREE.Color().setRGB(v, v, v, THREE.LinearSRGBColorSpace), 1);
    r.clear(true, false, false);
    r.setClearColor(prevC, prevA);
    r.setRenderTarget(prevT);
  }

  _pass(material, target) {
    const r = this.renderer;
    this.quad.material = material;
    const prevT = r.getRenderTarget();
    const prevS = r.getScissorTest();
    r.setRenderTarget(target);
    r.setScissorTest(false);
    r.render(this.quadScene, this.quadCam);
    r.setRenderTarget(prevT);
    r.setScissorTest(prevS);
  }

  _copyRT(src, dst) {
    this.copyMat.uniforms.tSrc.value = src.texture;
    this._pass(this.copyMat, dst);
  }

  _swapMask() {
    const t = this.maskRT; this.maskRT = this.tmpRT; this.tmpRT = t;
    this._bindMask();
  }

  // ----------------------------------------------------------------------------------------
  // mask operations (all GPU side)
  // ----------------------------------------------------------------------------------------
  _pushUndo() {
    const snap = new THREE.WebGLRenderTarget(this.maskSize, this.maskSize, {
      format: THREE.RedFormat, type: THREE.UnsignedByteType, minFilter: THREE.LinearFilter, magFilter: THREE.LinearFilter, depthBuffer: false, generateMipmaps: false,
    });
    this._copyRT(this.maskRT, snap);
    this.undoStack.push(snap);
    if (this.undoStack.length > 24) this.undoStack.shift().dispose();
    for (const s of this.redoStack) s.dispose();
    this.redoStack = [];
    this._updateUndoButtons();
  }

  undo() {
    if (!this.undoStack.length) return;
    const cur = new THREE.WebGLRenderTarget(this.maskSize, this.maskSize, {
      format: THREE.RedFormat, type: THREE.UnsignedByteType, minFilter: THREE.LinearFilter, magFilter: THREE.LinearFilter, depthBuffer: false, generateMipmaps: false,
    });
    this._copyRT(this.maskRT, cur);
    this.redoStack.push(cur);
    const snap = this.undoStack.pop();
    this._copyRT(snap, this.maskRT);
    snap.dispose();
    this._maskChanged();
  }

  redo() {
    if (!this.redoStack.length) return;
    const cur = new THREE.WebGLRenderTarget(this.maskSize, this.maskSize, {
      format: THREE.RedFormat, type: THREE.UnsignedByteType, minFilter: THREE.LinearFilter, magFilter: THREE.LinearFilter, depthBuffer: false, generateMipmaps: false,
    });
    this._copyRT(this.maskRT, cur);
    this.undoStack.push(cur);
    const snap = this.redoStack.pop();
    this._copyRT(snap, this.maskRT);
    snap.dispose();
    this._maskChanged();
  }

  _maskChanged() {
    this.maskVersion++;
    this.invalidate();
    this._updateUndoButtons();
    this._dirty('mask');
  }

  maskClear() { this._pushUndo(); this._clearRT(this.maskRT, 0); this._maskChanged(); }
  maskFill() { this._pushUndo(); this._pass(this.fillMat, this.maskRT); this._maskChanged(); }
  maskInvert() {
    this._pushUndo();
    this.invertMat.uniforms.tSrc.value = this.maskRT.texture;
    this._pass(this.invertMat, this.tmpRT);
    this._swapMask();
    this._maskChanged();
  }

  /** mode: 0 grow (dilate), 1 shrink (erode), 2 feather (box blur). amount in mask texels. */
  maskMorph(mode, amount) {
    const R = Math.max(1, Math.min(64, Math.round(amount)));
    this._pushUndo();
    const u = this.morphMat.uniforms;
    u.uR.value = R;
    u.uMode.value = mode;
    u.uStep.value.set(1 / this.maskSize, 0);
    u.tSrc.value = this.maskRT.texture;
    this._pass(this.morphMat, this.tmpRT);
    u.uStep.value.set(0, 1 / this.maskSize);
    u.tSrc.value = this.tmpRT.texture;
    this._pass(this.morphMat, this.maskRT);
    this._maskChanged();
  }

  /** Replace the mask with an image (white = masked). */
  importMaskBitmap(bmp, { undo = true } = {}) {
    if (undo) this._pushUndo();
    const c = document.createElement('canvas');
    c.width = c.height = this.maskSize;
    const ctx = c.getContext('2d');
    ctx.drawImage(bmp, 0, 0, c.width, c.height);
    const tex = new THREE.CanvasTexture(c);
    tex.colorSpace = THREE.NoColorSpace;
    tex.generateMipmaps = false;
    tex.minFilter = THREE.LinearFilter;
    this.copyMat.uniforms.tSrc.value = tex;
    this._pass(this.copyMat, this.maskRT);
    tex.dispose();
    this._maskChanged();
  }

  _readMaskPixels() {
    this.copyGreyMat.uniforms.tSrc.value = this.maskRT.texture;
    this._pass(this.copyGreyMat, this.readRT);
    const S = this.maskSize;
    const buf = new Uint8Array(S * S * 4);
    this.renderer.readRenderTargetPixels(this.readRT, 0, 0, S, S, buf);
    return buf; // bottom-up RGBA
  }

  _pixelsToCanvas(buf, w, h) {
    const c = document.createElement('canvas');
    c.width = w; c.height = h;
    const ctx = c.getContext('2d');
    const img = ctx.createImageData(w, h);
    const row = w * 4;
    for (let y = 0; y < h; y++) img.data.set(buf.subarray((h - 1 - y) * row, (h - y) * row), y * row); // flip vertically
    ctx.putImageData(img, 0, 0);
    return c;
  }

  _canvasToBlob(c, type = 'image/png') {
    return new Promise((res, rej) => c.toBlob((b) => (b ? res(b) : rej(new Error('canvas.toBlob failed'))), type));
  }

  async exportMaskBlob() {
    const buf = this._readMaskPixels();
    return this._canvasToBlob(this._pixelsToCanvas(buf, this.maskSize, this.maskSize));
  }

  maskIsEmpty() {
    const buf = this._readMaskPixels();
    for (let i = 0; i < buf.length; i += 4) if (buf[i] > 2) return false;
    return true;
  }

  // ----------------------------------------------------------------------------------------
  // texture handling
  // ----------------------------------------------------------------------------------------
  _setTexCanvas(canvas) {
    if (this.texTex) this.texTex.dispose();
    this.texCanvas = canvas;
    const t = new THREE.CanvasTexture(canvas);
    t.colorSpace = THREE.NoColorSpace;
    t.generateMipmaps = true;
    t.minFilter = THREE.LinearMipmapLinearFilter;
    t.magFilter = THREE.LinearFilter;
    t.anisotropy = this.maxAniso;
    t.wrapS = t.wrapT = THREE.ClampToEdgeWrapping;
    this.texTex = t;
    this._bindTexture();
    this.textureVersion++;
    this.invalidate();
  }

  _bindTexture() {
    const t = this.compare && this.resTex ? this.resTex : this.texTex;
    this.meshMat.uniforms.tColor.value = t;
    this.uvMat.uniforms.tColor.value = t;
    this.passMat.uniforms.tColor.value = this.texTex;
    this.invalidate();
  }

  _makeBlankTexture(size, color, h = size) {
    const c = document.createElement('canvas');
    c.width = size; c.height = h;
    const ctx = c.getContext('2d');
    ctx.fillStyle = color;
    ctx.fillRect(0, 0, size, h);
    this._setTexCanvas(c);
  }

  newTexture(size, color) {
    this._pushTexHistory('before new texture');
    this._makeBlankTexture(size, color);
    this.log('ok', `New ${size}x${size} texture created.`);
    this._dirty('texture');
  }

  /** Draw any image source (ImageBitmap / HTMLImageElement / canvas) as the current texture. */
  setTextureFromImage(img, { label = 'texture loaded', keepHistory = true } = {}) {
    const w0 = img.width || img.naturalWidth;
    const h0 = img.height || img.naturalHeight;
    if (!w0 || !h0) throw new Error('Texture image has no size.');
    const k = Math.min(1, 4096 / Math.max(w0, h0));
    const w = Math.max(16, Math.round(w0 * k)), h = Math.max(16, Math.round(h0 * k));
    if (keepHistory && this.texCanvas) this._pushTexHistory('before ' + label);
    const c = document.createElement('canvas');
    c.width = w; c.height = h;
    const ctx = c.getContext('2d');
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, w, h);
    ctx.drawImage(img, 0, 0, w, h);
    this._setTexCanvas(c);
    this.log('ok', `Texture set (${w}x${h}).`);
    this._dirty('texture');
  }

  async loadTextureFile(file) {
    const bmp = await createImageBitmap(file);
    this.setTextureFromImage(bmp, { label: 'texture ' + (file.name || '') });
    bmp.close && bmp.close();
  }

  async exportTextureBlob() { return this._canvasToBlob(this.texCanvas); }

  async _pushTexHistory(label) {
    if (!this.texCanvas) return;
    try {
      const bmp = await createImageBitmap(this.texCanvas);
      this.texHistory.push({ label, bmp, time: new Date() });
      if (this.texHistory.length > 10) this.texHistory.shift().bmp.close();
      this._renderHistory();
    } catch (e) { this.log('warn', 'Could not store texture history', e); }
  }

  revertTexture(i) {
    const e = this.texHistory[i];
    if (!e) return;
    const c = document.createElement('canvas');
    c.width = e.bmp.width; c.height = e.bmp.height;
    c.getContext('2d').drawImage(e.bmp, 0, 0);
    this._setTexCanvas(c);
    this.log('ok', `Reverted texture to "${e.label}".`);
    this._dirty('texture');
  }

  // ----------------------------------------------------------------------------------------
  // generation result (comes back from the Bake node)
  // ----------------------------------------------------------------------------------------
  showResult(bmp, remainingBmp, stats) {
    const c = document.createElement('canvas');
    c.width = bmp.width; c.height = bmp.height;
    c.getContext('2d').drawImage(bmp, 0, 0);
    if (this.resTex) this.resTex.dispose();
    this.resCanvas = c;
    const t = new THREE.CanvasTexture(c);
    t.colorSpace = THREE.NoColorSpace;
    t.generateMipmaps = true;
    t.minFilter = THREE.LinearMipmapLinearFilter;
    t.anisotropy = this.maxAniso;
    this.resTex = t;
    this.pending = { remaining: remainingBmp || null, stats: stats || {} };
    this.compare = true; // show the new result immediately
    this._bindTexture();
    this._renderBanner();
    this.log('ok', 'Generation result received.' + (stats && stats.summary ? ' ' + stats.summary : ''));
    if (this.state.options.autoApply) this.applyResult();
  }

  toggleCompare() {
    if (!this.pending) return;
    this.compare = !this.compare;
    this._bindTexture();
    this._renderBanner();
  }

  applyResult() {
    if (!this.pending) return;
    this._pushTexHistory('before AI result');
    const c = document.createElement('canvas');
    c.width = this.resCanvas.width; c.height = this.resCanvas.height;
    c.getContext('2d').drawImage(this.resCanvas, 0, 0);
    const rem = this.pending.remaining;
    this.pending = null;
    this.compare = false;
    if (this.resTex) { this.resTex.dispose(); this.resTex = null; }
    this._setTexCanvas(c);
    if (rem && this.state.options.clearMask) this.importMaskBitmap(rem);
    this._renderBanner();
    this.log('ok', 'Result applied to the texture.');
    this._dirty('texture');
  }

  discardResult() {
    this.pending = null;
    this.compare = false;
    if (this.resTex) { this.resTex.dispose(); this.resTex = null; }
    this._bindTexture();
    this._renderBanner();
  }

  // ----------------------------------------------------------------------------------------
  // model loading
  // ----------------------------------------------------------------------------------------
  async loadModelBuffer(buffer, name, { keepTexture = false } = {}) {
    const ext = extOf(name);
    this.setStatus('Loading ' + name + ' ...');
    const t0 = performance.now();
    try {
      const { root, kind } = await parseModel(buffer, ext);
      const { geometry, info } = buildMerged(root, kind);
      this._setGeometry(geometry, info);
      this.state.model = { name, ext };
      if (!keepTexture) {
        if (info.embedded) {
          try { this.setTextureFromImage(info.embedded, { label: 'model texture', keepHistory: false }); this.log('ok', 'Using the texture embedded in the model.'); }
          catch (e) { this.log('warn', 'Embedded texture could not be used; blank texture created.', e); this._makeBlankTexture(2048, '#c8c8c8'); }
        } else {
          this._makeBlankTexture(2048, '#c8c8c8');
        }
        this._clearRT(this.maskRT, 0);
        this.undoStack.forEach((s) => s.dispose()); this.undoStack = [];
        this.redoStack.forEach((s) => s.dispose()); this.redoStack = [];
        this._updateUndoButtons();
        this.maskVersion++;
      }
      this.frameModel();
      for (const w of info.warnings) this.log('warn', w);
      this.log('ok', `Loaded ${name}: ${info.triangles.toLocaleString()} triangles, ${info.vertices.toLocaleString()} vertices (${Math.round(performance.now() - t0)} ms).`);
      this.setStatus(info.warnings[0] || `Loaded ${name}`, info.warnings.length ? 'warn' : 'ok');
      this._dirty('model');
      this._renderStats();
    } catch (e) {
      this.log('error', `Could not load "${name}"`, e);
      this.setStatus(`Could not load "${name}": ${e.message}`, 'err');
      throw e;
    }
  }

  _setGeometry(geometry, info) {
    if (this.mesh) { this.scene.remove(this.mesh); this.scene.remove(this.wireMesh); this.geometry.dispose(); }
    if (this.depthMesh) this.depthScene.remove(this.depthMesh);
    if (this.paintMesh) this.paintScene.remove(this.paintMesh);
    if (this.passMesh) this.passScene.remove(this.passMesh);
    if (this.uvLines) { this.uvScene.remove(this.uvLines); this.uvLines.geometry.dispose(); }
    this.geometry = geometry;
    this.info = info;
    this.meshHash = hashGeometry(geometry);
    this.mesh = new THREE.Mesh(geometry, this.meshMat);
    this.mesh.frustumCulled = false;
    this.wireMesh = new THREE.Mesh(geometry, this.wireMat);
    this.wireMesh.frustumCulled = false;
    this.wireMesh.visible = !!this.state.display.wire3d;
    this.scene.add(this.mesh, this.wireMesh);
    this.depthMesh = new THREE.Mesh(geometry, this.depthMat); this.depthMesh.frustumCulled = false; this.depthScene.add(this.depthMesh);
    this.paintMesh = new THREE.Mesh(geometry, this.paintMat); this.paintMesh.frustumCulled = false; this.paintScene.add(this.paintMesh);
    this.passMesh = new THREE.Mesh(geometry, this.passMat); this.passMesh.frustumCulled = false; this.passScene.add(this.passMesh);
    const lg = new THREE.BufferGeometry();
    lg.setAttribute('position', new THREE.BufferAttribute(buildUVLines(geometry), 3));
    this.uvLines = new THREE.LineSegments(lg, this.uvLineMat);
    this.uvLines.frustumCulled = false;
    this.uvLines.renderOrder = 2;
    this.uvScene.add(this.uvLines);
    this.ui.empty.style.display = 'none';
    this.invalidate();
  }

  get hasModel() { return !!this.geometry; }

  frameModel() {
    const dir = new THREE.Vector3(0.35, 0.3, 1).normalize();
    this.controls.target.set(0, 0, 0);
    this.camera.position.copy(dir.multiplyScalar(3.3));
    this.camera.near = 0.02;
    this.camera.updateProjectionMatrix();
    this.controls.update();
    this.uvView = { cx: 0.5, cy: 0.5, zoom: 1 };
    this.invalidate();
  }

  frameMask() {
    if (!this.hasModel) return;
    const S = this.maskSize;
    const px = this._readMaskPixels();
    const pos = this.geometry.attributes.position.array;
    const uv = this.geometry.attributes.uv.array;
    const idx = this.geometry.index.array;
    const box = new THREE.Box3();
    const p = new THREE.Vector3();
    let any = false;
    for (let t = 0; t + 2 < idx.length; t += 3) {
      const a = idx[t], b = idx[t + 1], c = idx[t + 2];
      const u = (uv[a * 2] + uv[b * 2] + uv[c * 2]) / 3;
      const v = (uv[a * 2 + 1] + uv[b * 2 + 1] + uv[c * 2 + 1]) / 3;
      const ix = Math.min(S - 1, Math.max(0, Math.floor(u * S)));
      const iy = Math.min(S - 1, Math.max(0, Math.floor(v * S)));
      if (px[(iy * S + ix) * 4] > 40) {
        p.set((pos[a * 3] + pos[b * 3] + pos[c * 3]) / 3, (pos[a * 3 + 1] + pos[b * 3 + 1] + pos[c * 3 + 1]) / 3, (pos[a * 3 + 2] + pos[b * 3 + 2] + pos[c * 3 + 2]) / 3);
        box.expandByPoint(p);
        any = true;
      }
    }
    if (!any) { this.setStatus('Mask is empty - nothing to frame.', 'warn'); return; }
    const center = box.getCenter(new THREE.Vector3());
    const radius = Math.max(0.08, box.getSize(new THREE.Vector3()).length() / 2);
    const dir = this.camera.position.clone().sub(this.controls.target).normalize();
    const dist = Math.max(0.4, radius / Math.sin(THREE.MathUtils.degToRad(this.camera.fov) / 2) * 1.25);
    this.controls.target.copy(center);
    this.camera.position.copy(center).addScaledVector(dir, dist);
    this.camera.near = 0.02;
    this.camera.updateProjectionMatrix();
    this.controls.update();
    this.invalidate();
  }

  // ----------------------------------------------------------------------------------------
  // projective painting
  // ----------------------------------------------------------------------------------------
  _paneSize(el) { return { w: Math.max(1, el.offsetWidth), h: Math.max(1, el.offsetHeight) }; }

  _ensureDepthRT(w, h) {
    if (this.depthRT && this.depthRT.width === w && this.depthRT.height === h) return;
    if (this.depthRT) { this.depthRT.depthTexture.dispose(); this.depthRT.dispose(); }
    const dt = new THREE.DepthTexture(w, h);
    dt.type = THREE.UnsignedIntType;
    dt.minFilter = dt.magFilter = THREE.NearestFilter;
    this.depthRT = new THREE.WebGLRenderTarget(w, h, { depthBuffer: true, depthTexture: dt, minFilter: THREE.NearestFilter, magFilter: THREE.NearestFilter, generateMipmaps: false });
  }

  _syncCamera() {
    const { w, h } = this._paneSize(this.ui.pane3d);
    if (Math.abs(this.camera.aspect - w / h) > 1e-6) { this.camera.aspect = w / h; this.camera.updateProjectionMatrix(); }
    this.camera.updateMatrixWorld(true);
  }

  beginStroke(erase) {
    if (!this.hasModel || !this.info.hasUV) return false;
    const { w, h } = this._paneSize(this.ui.pane3d);
    this._syncCamera();
    this._ensureDepthRT(w, h);
    const r = this.renderer;
    const prevT = r.getRenderTarget(), prevS = r.getScissorTest();
    r.setRenderTarget(this.depthRT);
    r.setScissorTest(false);
    const prevC = new THREE.Color(); r.getClearColor(prevC); const prevA = r.getClearAlpha();
    r.setClearColor(0x000000, 1);
    r.clear(true, true, false);
    r.render(this.depthScene, this.camera);
    r.setClearColor(prevC, prevA);
    r.setRenderTarget(prevT);
    r.setScissorTest(prevS);
    this._pushUndo();
    this.stroke = { erase, w, h, last: null, smooth: null, pending: false };
    return true;
  }

  /** One dab. x,y in pane pixels (origin top-left). */
  _dab(x, y, pressure) {
    const s = this.stroke;
    const t = s.erase ? this.state.erase : this.state.brush;
    let rad = t.size * 0.5;
    let op = t.opacity;
    if (this.state.pen && pressure > 0 && pressure < 1) { rad *= 0.25 + 0.75 * pressure; op *= 0.3 + 0.7 * pressure; }
    const mat = s.erase ? this.eraseMat : this.paintMat;
    const u = mat.uniforms;
    u.uVP.value.multiplyMatrices(this.camera.projectionMatrix, this.camera.matrixWorldInverse);
    u.uCam.value.copy(this.camera.position);
    u.uCenter.value.set(x, s.h - y);
    u.uSize.value.set(s.w, s.h);
    u.uRadius.value = Math.max(0.5, rad);
    u.uHardness.value = t.hardness;
    u.uSoft.value = t.softness;
    u.uOpacity.value = op;
    u.uDepth.value = this.depthRT.depthTexture;
    u.uNear.value = this.camera.near;
    u.uFar.value = this.camera.far;
    u.uBias.value = 0.006;
    this.paintMesh.material = mat;
    const r = this.renderer;
    const prevT = r.getRenderTarget(), prevS = r.getScissorTest();
    r.setRenderTarget(this.maskRT);
    r.setScissorTest(false);
    r.render(this.paintScene, this.quadCam);
    r.setRenderTarget(prevT);
    r.setScissorTest(prevS);
    this.invalidate();
  }

  strokeMove(x, y, pressure) {
    const s = this.stroke;
    if (!s) return;
    const t = s.erase ? this.state.erase : this.state.brush;
    if (!s.smooth) { s.smooth = { x, y }; s.last = { x, y }; this._dab(x, y, pressure); return; }
    const k = 1 - Math.min(0.95, t.stab * 0.95);
    s.smooth.x += (x - s.smooth.x) * k;
    s.smooth.y += (y - s.smooth.y) * k;
    const step = Math.max(1, t.spacing * t.size);
    let dx = s.smooth.x - s.last.x, dy = s.smooth.y - s.last.y;
    let d = Math.hypot(dx, dy);
    let guard = 0;
    while (d >= step && guard++ < 400) {
      const f = step / d;
      s.last.x += dx * f; s.last.y += dy * f;
      this._dab(s.last.x, s.last.y, pressure);
      dx = s.smooth.x - s.last.x; dy = s.smooth.y - s.last.y; d = Math.hypot(dx, dy);
    }
  }

  endStroke() {
    if (!this.stroke) return;
    this.stroke = null;
    this._maskChanged();
  }

  // ----------------------------------------------------------------------------------------
  // capture (the passes consumed by the Python nodes)
  // ----------------------------------------------------------------------------------------
  captureSize() {
    const cap = this.state.capture;
    const [aw, ah] = cap.aspect.split(':').map(Number);
    let W, H;
    if (aw >= ah) { W = cap.long; H = cap.long * ah / aw; } else { H = cap.long; W = cap.long * aw / ah; }
    const snap = (v) => Math.max(64, Math.round(v / 16) * 16);
    return [snap(W), snap(H)];
  }

  /** Largest rectangle with the capture aspect that fits inside the 3D pane (pane pixels). */
  frameRect(w, h) {
    const [cw, ch] = this.captureSize();
    const A = cw / ch;
    let fw = Math.min(w, h * A);
    let fh = fw / A;
    return { x: (w - fw) / 2, y: (h - fh) / 2, w: fw, h: fh };
  }

  _captureCamera(W, H) {
    this._syncCamera();
    const { w, h } = this._paneSize(this.ui.pane3d);
    const fr = this.frameRect(w, h);
    const cam = this.camera.clone();
    cam.aspect = W / H;
    const tanHalf = Math.tan(THREE.MathUtils.degToRad(this.camera.fov) / 2) * (fr.h / h);
    cam.fov = THREE.MathUtils.radToDeg(2 * Math.atan(tanHalf));
    const dist = cam.position.length();
    cam.near = Math.max(0.01, dist - 1.15);
    cam.far = dist + 1.15;
    cam.updateProjectionMatrix();
    cam.updateMatrixWorld(true);
    return cam;
  }

  _renderPassToBlob(rt, cam, mode, clearRGB, shade) {
    const r = this.renderer;
    const u = this.passMat.uniforms;
    u.uMode.value = mode;
    u.uShade.value = shade;
    u.uNear.value = cam.near;
    u.uFar.value = cam.far;
    const prevT = r.getRenderTarget(), prevS = r.getScissorTest();
    const prevC = new THREE.Color(); r.getClearColor(prevC); const prevA = r.getClearAlpha();
    r.setRenderTarget(rt);
    r.setScissorTest(false);
    r.setClearColor(new THREE.Color().setRGB(clearRGB[0], clearRGB[1], clearRGB[2], THREE.LinearSRGBColorSpace), 1);
    r.clear(true, true, false);
    r.render(this.passScene, cam);
    const buf = new Uint8Array(rt.width * rt.height * 4);
    r.readRenderTargetPixels(rt, 0, 0, rt.width, rt.height, buf);
    r.setClearColor(prevC, prevA);
    r.setRenderTarget(prevT);
    r.setScissorTest(prevS);
    return this._canvasToBlob(this._pixelsToCanvas(buf, rt.width, rt.height));
  }

  /**
   * Renders view / mask / depth / normal for the current camera and returns everything the backend needs.
   * includeMesh / includeTexture can be false when the server already holds the latest copy.
   */
  async capture({ includeMesh = true, includeTexture = true } = {}) {
    if (!this.hasModel) throw new Error('No model loaded in the Texture Painter node.');
    if (!this.info.hasUV) throw new Error('The loaded model has no UV coordinates.');
    const cap = this.state.capture;
    const [W, H] = this.captureSize();
    const cam = this._captureCamera(W, H);
    const bg = hexToRaw(cap.bg);
    const rtMS = new THREE.WebGLRenderTarget(W, H, { format: THREE.RGBAFormat, type: THREE.UnsignedByteType, depthBuffer: true, samples: 4, generateMipmaps: false });
    const rt = new THREE.WebGLRenderTarget(W, H, { format: THREE.RGBAFormat, type: THREE.UnsignedByteType, depthBuffer: true, generateMipmaps: false });
    const out = {};
    try {
      const shade = cap.shading === 'soft' ? 0.35 : 0;
      out.view = await this._renderPassToBlob(rtMS, cam, 0, bg, shade);
      out.viewmask = await this._renderPassToBlob(rt, cam, 3, [0, 0, 0], 0);
      out.depth = await this._renderPassToBlob(rt, cam, 1, [1, 1, 1], 0);
      out.normal = await this._renderPassToBlob(rt, cam, 2, [0.5, 0.5, 1], 0);
    } finally {
      rtMS.dispose(); rt.dispose();
    }
    out.uvmask = await this.exportMaskBlob();
    if (includeTexture) out.texture = await this.exportTextureBlob();
    if (includeMesh) out.mesh = new Blob([serializeMesh(this.geometry, this.meshHash)], { type: 'application/octet-stream' });
    out.meta = {
      version: 1,
      mesh_hash: this.meshHash,
      view_size: [W, H],
      tex_size: [this.texCanvas.width, this.texCanvas.height],
      facing: cap.facing,
      shading: cap.shading,
      bg: cap.bg,
      camera: {
        view: cam.matrixWorldInverse.toArray(),
        proj: cam.projectionMatrix.toArray(),
        near: cam.near,
        far: cam.far,
        fov: cam.fov,
        aspect: cam.aspect,
        width: W,
        height: H,
        position: cam.position.toArray(),
      },
      model: this.state.model,
      triangles: this.info.triangles,
      texture_version: this.textureVersion,
    };
    return out;
  }

  // ----------------------------------------------------------------------------------------
  // state
  // ----------------------------------------------------------------------------------------
  getState() {
    const s = JSON.parse(JSON.stringify(this.state));
    if (this.camera) {
      s.camera = { pos: this.camera.position.toArray().map((v) => +v.toFixed(5)), target: this.controls.target.toArray().map((v) => +v.toFixed(5)), fov: this.camera.fov };
    }
    return s;
  }

  applyState(s) {
    if (!s || typeof s !== 'object') return;
    deepMerge(this.state, s);
    this._applyStateToUI();
    if (s.camera && s.camera.pos && s.camera.target) {
      this.camera.position.fromArray(s.camera.pos);
      this.controls.target.fromArray(s.camera.target);
      if (s.camera.fov) this.camera.fov = s.camera.fov;
      this.camera.updateProjectionMatrix();
      this.controls.update();
    }
    this.invalidate();
  }

  _cameraTouched() { this._dirty('camera'); }

  _dirty(kind) {
    if (this.hooks.onDirty) this.hooks.onDirty(kind);
    clearTimeout(this._emitTimer);
    this._emitTimer = setTimeout(() => { if (this.hooks.onState && !this.disposed) this.hooks.onState(this.getState()); }, 300);
    if (kind !== 'brush' && kind !== 'settings') this._setSyncLabel(false);
  }

  _setSyncLabel(synced) {
    this.synced = synced;
    const el = this.ui.syncState;
    el.textContent = synced ? '● synced' : '● changed';
    el.style.color = synced ? '#4cc38a' : '#f0a23a';
  }

  markSynced() { this._setSyncLabel(true); }

  // ----------------------------------------------------------------------------------------
  // render loop
  // ----------------------------------------------------------------------------------------
  _startLoop() {
    const loop = () => {
      if (this.disposed) return;
      if (this.needsRender) {
        this.needsRender = false;
        try { this._render(); } catch (e) { this.log('error', 'Render failed', e); }
      }
      if (this.hudDirty) {
        this.hudDirty = false;
        try { this._drawHUD(); } catch (e) { this.log('error', 'HUD failed', e); }
      }
      this._raf = requestAnimationFrame(loop);
    };
    this._raf = requestAnimationFrame(loop);
  }

  _updateUVCam(w, h) {
    const a = w / h;
    const halfH = Math.max(0.56, 0.56 / a) / this.uvView.zoom;
    const halfW = halfH * a;
    const c = this.uvCam;
    c.left = -halfW; c.right = halfW; c.top = halfH; c.bottom = -halfH;
    c.position.set(this.uvView.cx, this.uvView.cy, 5);
    c.updateProjectionMatrix();
    return { halfW, halfH };
  }

  _render() {
    const r = this.renderer;
    const W = this.ui.stage.clientWidth, H = this.ui.stage.clientHeight;
    if (W < 2 || H < 2) return;
    if (this._sw !== W || this._sh !== H) {
      r.setSize(W, H, false);
      this._sw = W; this._sh = H;
      const hud = this.ui.hudCanvas;
      hud.width = Math.round(W * this.dpr); hud.height = Math.round(H * this.dpr);
      this.hudDirty = true;
    }
    // uniforms from state
    const st = this.state;
    const mu = this.meshMat.uniforms, uu = this.uvMat.uniforms;
    mu.uShowMask.value = uu.uShowMask.value = st.mask.show ? 1 : 0;
    mu.uMaskOpacity.value = uu.uMaskOpacity.value = st.mask.opacity;
    mu.uShade.value = st.display.shade3d;
    mu.uFacingThr.value = st.capture.facing;
    this.uvLineMat.opacity = st.display.uvWire;
    this.uvLines && (this.uvLines.visible = st.display.uvWire > 0.001);
    if (this.wireMesh) this.wireMesh.visible = !!st.display.wire3d;

    r.setRenderTarget(null);
    r.setScissorTest(false);
    r.setViewport(0, 0, W, H);
    r.setClearColor(0x101216, 1);
    r.clear(true, true, true);

    const draw = (pane, fn) => {
      if (pane.classList.contains('tp-hidden')) return;
      const w = pane.offsetWidth, h = pane.offsetHeight;
      if (w < 2 || h < 2) return;
      const x = pane.offsetLeft, y = H - pane.offsetTop - h;
      r.setViewport(x, y, w, h);
      r.setScissor(x, y, w, h);
      r.setScissorTest(true);
      fn(w, h);
    };
    draw(this.ui.pane3d, (w, h) => {
      r.setClearColor(0x20232b, 1);
      r.clear(true, true, true);
      this.camera.aspect = w / h;
      this.camera.updateProjectionMatrix();
      r.render(this.scene, this.camera);
    });
    draw(this.ui.paneUV, (w, h) => {
      r.setClearColor(0x16181d, 1);
      r.clear(true, true, true);
      this._updateUVCam(w, h);
      r.render(this.uvScene, this.uvCam);
    });
    r.setScissorTest(false);
  }

  // ----------------------------------------------------------------------------------------
  dispose() {
    this.disposed = true;
    cancelAnimationFrame(this._raf);
    clearTimeout(this._emitTimer);
    if (this._ro) this._ro.disconnect();
    if (this._unbind) this._unbind();
    try { this.controls.dispose(); } catch (_) { /* ignore */ }
    try { this.renderer.dispose(); this.renderer.forceContextLoss(); } catch (_) { /* ignore */ }
    this.undoStack.forEach((s) => s.dispose());
    this.redoStack.forEach((s) => s.dispose());
    if (this.root.parentNode) this.root.parentNode.removeChild(this.root);
  }
}

export { SUPPORTED_EXT };
