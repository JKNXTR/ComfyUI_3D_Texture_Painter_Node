// Panels, HUD drawing and all DOM event wiring for the editor. Installed onto an editor instance.
import * as THREE from 'three';
import { makeSlider, makeCheck, makeButton, h } from './ui.js';
import { extOf, SUPPORTED_EXT } from './meshio.js';

const IMG_EXT = ['png', 'jpg', 'jpeg', 'webp', 'bmp', 'tga'];

function download(blob, name) {
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = name;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 4000);
}

export function installPanels(ed) {
  const ui = ed.ui;
  const st = ed.state;
  const W = (ed._w = {});
  const curTool = () => (st.tool === 'erase' ? st.erase : st.brush);
  const settle = () => ed._dirty('settings');

  // =========================================================================================
  // panels
  // =========================================================================================
  const brushSummary = ui.sec.brush.el.querySelector('summary');
  const bs = ui.sec.brush.body;
  W.size = makeSlider('Size', { min: 2, max: 400, step: 1, value: 70, fmt: (v) => v + ' px' }, (v) => { curTool().size = v; ed.hudDirty = true; ed._dirty('brush'); });
  W.hard = makeSlider('Hardness', { min: 0, max: 100, step: 1, value: 70, fmt: (v) => v + '%' }, (v) => { curTool().hardness = v / 100; ed.hudDirty = true; ed._dirty('brush'); });
  W.soft = makeSlider('Softness', { min: 0, max: 100, step: 1, value: 50, fmt: (v) => v + '%' }, (v) => { curTool().softness = v / 100; ed._dirty('brush'); });
  W.opac = makeSlider('Opacity', { min: 1, max: 100, step: 1, value: 100, fmt: (v) => v + '%' }, (v) => { curTool().opacity = v / 100; ed._dirty('brush'); });
  W.space = makeSlider('Spacing', { min: 2, max: 100, step: 1, value: 12, fmt: (v) => v + '%' }, (v) => { curTool().spacing = v / 100; ed._dirty('brush'); });
  W.stab = makeSlider('Stabilizer', { min: 0, max: 100, step: 1, value: 20, fmt: (v) => v + '%' }, (v) => { curTool().stab = v / 100; ed._dirty('brush'); });
  W.pen = makeCheck('Pen pressure (tablet)', st.pen, (v) => { st.pen = v; ed._dirty('brush'); });
  bs.append(W.size.el, W.hard.el, W.soft.el, W.opac.el, W.space.el, W.stab.el, W.pen.el);
  const note = h('div', 'tp-note', 'Hardness = size of the fully opaque core. Softness = smoothness of the falloff. Brush and eraser keep separate settings.');
  bs.append(note);

  const ms = ui.sec.mask.body;
  W.showMask = makeCheck('Show mask (M)', st.mask.show, (v) => { st.mask.show = v; ed.invalidate(); ed._dirty('settings'); });
  W.maskOp = makeSlider('Overlay', { min: 5, max: 100, step: 1, value: 60, fmt: (v) => v + '%' }, (v) => { st.mask.opacity = v / 100; ed.invalidate(); });
  W.amount = makeSlider('Amount', { min: 1, max: 64, step: 1, value: 8, fmt: (v) => v + ' px' }, (v) => { st.mask.amount = v; });
  const mkRow = (...btns) => { const r = h('div', 'tp-row2'); r.append(...btns); return r; };
  const bClear = makeButton('Clear'), bFill = makeButton('Fill all'), bInv = makeButton('Invert');
  const bGrow = makeButton('Grow'), bShrink = makeButton('Shrink'), bFeather = makeButton('Feather');
  const bImpMask = makeButton('Import PNG'), bExpMask = makeButton('Export PNG');
  bClear.onclick = () => ed.maskClear();
  bFill.onclick = () => ed.maskFill();
  bInv.onclick = () => ed.maskInvert();
  bGrow.onclick = () => ed.maskMorph(0, st.mask.amount);
  bShrink.onclick = () => ed.maskMorph(1, st.mask.amount);
  bFeather.onclick = () => ed.maskMorph(2, st.mask.amount);
  const maskFile = h('input'); maskFile.type = 'file'; maskFile.accept = 'image/*'; maskFile.style.display = 'none';
  maskFile.onchange = async () => {
    const f = maskFile.files[0]; maskFile.value = '';
    if (!f) return;
    try { const bmp = await createImageBitmap(f); ed.importMaskBitmap(bmp); ed.log('ok', 'Mask imported.'); } catch (e) { ed.log('error', 'Mask import failed', e); }
  };
  bImpMask.onclick = () => maskFile.click();
  bExpMask.onclick = async () => { try { download(await ed.exportMaskBlob(), 'uv_mask.png'); } catch (e) { ed.log('error', 'Mask export failed', e); } };
  ms.append(W.showMask.el, W.maskOp.el, mkRow(bClear, bFill, bInv), W.amount.el, mkRow(bGrow, bShrink, bFeather), mkRow(bImpMask, bExpMask), maskFile);
  ms.append(h('div', 'tp-note', 'The mask lives in UV space, so it is independent of the camera. Orange = masked area seen at a grazing angle (poor bake from this view).'));

  const cs = ui.sec.cap.body;
  const aspectSel = h('select');
  for (const a of ['1:1', '4:3', '3:4', '3:2', '2:3', '16:9', '9:16']) { const o = h('option', null, a); o.value = a; aspectSel.append(o); }
  aspectSel.onchange = () => { st.capture.aspect = aspectSel.value; updateCapLabel(); ed.invalidate(); ed._dirty('capture'); };
  const aspectRow = h('div', 'tp-row'); aspectRow.append(h('span', 'tp-lbl', 'Aspect'), aspectSel, h('span'));
  W.long = makeSlider('Long side', { min: 256, max: 2048, step: 64, value: 1024, fmt: (v) => v }, (v) => { st.capture.long = v; updateCapLabel(); ed.invalidate(); ed._dirty('capture'); });
  const shadeSel = h('select');
  for (const [v, t] of [['unlit', 'Unlit (albedo only)'], ['soft', 'Soft shading']]) { const o = h('option', null, t); o.value = v; shadeSel.append(o); }
  shadeSel.onchange = () => { st.capture.shading = shadeSel.value; ed._dirty('capture'); };
  const shadeRow = h('div', 'tp-row'); shadeRow.append(h('span', 'tp-lbl', 'Shading'), shadeSel, h('span'));
  const bgIn = h('input'); bgIn.type = 'color'; bgIn.value = '#808080';
  bgIn.oninput = () => { st.capture.bg = bgIn.value; ed._dirty('capture'); };
  const bgRow = h('div', 'tp-row'); bgRow.append(h('span', 'tp-lbl', 'Background'), bgIn, h('span'));
  W.facing = makeSlider('Min facing', { min: 0, max: 90, step: 1, value: 25, fmt: (v) => (v / 100).toFixed(2) }, (v) => { st.capture.facing = v / 100; ed.invalidate(); ed._dirty('capture'); });
  W.frame = makeCheck('Show capture frame', st.capture.frame, (v) => { st.capture.frame = v; ed.hudDirty = true; });
  const capLabel = h('div', 'tp-note');
  const updateCapLabel = () => { const [w, hh] = ed.captureSize(); capLabel.textContent = `Output size: ${w} x ${hh}. Everything inside the frame is sent to the generator.`; ed.hudDirty = true; };
  cs.append(aspectRow, W.long.el, shadeRow, bgRow, W.facing.el, W.frame.el, capLabel);
  ed._updateCapLabel = updateCapLabel;

  const ds = ui.sec.disp.body;
  W.wire = makeCheck('3D wireframe overlay', st.display.wire3d, (v) => { st.display.wire3d = v; ed.invalidate(); ed._dirty('settings'); });
  W.shade = makeSlider('3D shading', { min: 0, max: 100, step: 1, value: 0, fmt: (v) => v + '%' }, (v) => { st.display.shade3d = v / 100; ed.invalidate(); });
  W.uvwire = makeSlider('UV lines', { min: 0, max: 100, step: 1, value: 35, fmt: (v) => v + '%' }, (v) => { st.display.uvWire = v / 100; ed.invalidate(); });
  ds.append(W.wire.el, W.shade.el, W.uvwire.el);

  const rs = ui.sec.res.body;
  W.clearMask = makeCheck('Remove baked area from mask after Apply', st.options.clearMask, (v) => { st.options.clearMask = v; ed._dirty('settings'); });
  W.autoApply = makeCheck('Apply results automatically', st.options.autoApply, (v) => { st.options.autoApply = v; ed._dirty('settings'); });
  rs.append(W.clearMask.el, W.autoApply.el, h('div', 'tp-note', 'When the Bake node finishes, the new texture is shown here. Apply it, compare it with the old one, or discard it. Applied results are stored in Texture history.'));

  // ---- bottom clipboards / logs
  ui.btn.bCopyLog.onclick = () => { navigator.clipboard && navigator.clipboard.writeText(ed.logLines.join('\n')).then(() => ed.setStatus('Log copied to clipboard.', 'ok')); };
  ui.btn.bClearLog.onclick = () => { ed.logLines = []; ui.logEl.innerHTML = ''; };

  // =========================================================================================
  // methods used by the core
  // =========================================================================================
  ed._applyStateToUI = () => {
    const t = curTool();
    brushSummary.textContent = st.tool === 'erase' ? 'Eraser' : 'Brush';
    W.size.set(t.size); W.hard.set(Math.round(t.hardness * 100)); W.soft.set(Math.round(t.softness * 100));
    W.opac.set(Math.round(t.opacity * 100)); W.space.set(Math.round(t.spacing * 100)); W.stab.set(Math.round(t.stab * 100));
    W.pen.set(st.pen);
    W.showMask.set(st.mask.show); W.maskOp.set(Math.round(st.mask.opacity * 100)); W.amount.set(st.mask.amount);
    aspectSel.value = st.capture.aspect; W.long.set(st.capture.long); shadeSel.value = st.capture.shading; bgIn.value = st.capture.bg;
    W.facing.set(Math.round(st.capture.facing * 100)); W.frame.set(st.capture.frame);
    W.wire.set(st.display.wire3d); W.shade.set(Math.round(st.display.shade3d * 100)); W.uvwire.set(Math.round(st.display.uvWire * 100));
    W.clearMask.set(st.options.clearMask); W.autoApply.set(st.options.autoApply);
    ui.layout.value = st.display.layout;
    ui.btn.tBrush.classList.toggle('tp-on', st.tool === 'brush');
    ui.btn.tErase.classList.toggle('tp-on', st.tool === 'erase');
    ui.btn.tNav.classList.toggle('tp-on', st.tool === 'nav');
    ed._applyMouseButtons();
    ed._layoutPanes();
    updateCapLabel();
    ed._updateUndoButtons();
    ed._renderBanner();
    ed._renderHistory();
    ed._setSyncLabel(!!ed.synced);
  };

  ed.setTool = (name) => {
    st.tool = name;
    ed._applyStateToUI();
    ed.hudDirty = true;
    ed._dirty('brush');
  };

  ed._applyMouseButtons = () => {
    const nav = st.tool === 'nav' || ed.spaceDown;
    ed.controls.mouseButtons = nav
      ? { LEFT: THREE.MOUSE.ROTATE, MIDDLE: THREE.MOUSE.DOLLY, RIGHT: THREE.MOUSE.PAN }
      : { LEFT: -1, MIDDLE: THREE.MOUSE.ROTATE, RIGHT: THREE.MOUSE.PAN };
  };

  ed._layoutPanes = () => {
    const l = st.display.layout;
    ui.pane3d.classList.toggle('tp-hidden', l === 'uv');
    ui.paneUV.classList.toggle('tp-hidden', l === '3d');
    ed.invalidate();
  };

  ed._updateUndoButtons = () => {
    ui.btn.tUndo.disabled = !ed.undoStack.length;
    ui.btn.tRedo.disabled = !ed.redoStack.length;
  };

  ed._renderStats = () => {
    const i = ed.info;
    ui.stats.textContent = i ? `${i.triangles.toLocaleString()} tris  |  ${ed.texCanvas ? ed.texCanvas.width + 'x' + ed.texCanvas.height : ''}` : '';
  };

  ed._renderHistory = () => {
    ui.histEl.innerHTML = '';
    if (!ed.texHistory.length) { ui.histEl.append(h('div', 'tp-note', 'No earlier texture versions yet.')); return; }
    ed.texHistory.forEach((e, i) => {
      const b = makeButton(`${e.time.toLocaleTimeString()}  -  ${e.label}`, 'Revert the texture to this version');
      b.onclick = () => ed.revertTexture(i);
      ui.histEl.append(b);
    });
  };

  ed._renderBanner = () => {
    const b = ui.banner;
    if (!ed.pending) { b.classList.add('tp-hidden'); b.innerHTML = ''; return; }
    b.classList.remove('tp-hidden');
    b.innerHTML = '';
    const stats = ed.pending.stats || {};
    b.append(h('div', null, 'AI result ready' + (stats.summary ? ' - ' + stats.summary : '')));
    const apply = makeButton('Apply', 'Overwrite the texture with the result', 'tp-pri');
    const cmp = makeButton(ed.compare ? 'Showing: new' : 'Showing: old', 'Toggle between old and new texture');
    const dis = makeButton('Discard');
    apply.onclick = () => ed.applyResult();
    cmp.onclick = () => ed.toggleCompare();
    dis.onclick = () => ed.discardResult();
    const row = h('div', 'tp-row2'); row.append(apply, cmp, dis);
    b.append(row);
    if (stats.warnings && stats.warnings.length) b.append(h('div', 'tp-note', stats.warnings.join(' ')));
  };

  // =========================================================================================
  // HUD (brush cursor, capture frame, UV cursor)
  // =========================================================================================
  const uvDims = (w, hh) => {
    const a = w / hh;
    const halfH = Math.max(0.56, 0.56 / a) / ed.uvView.zoom;
    return { halfW: halfH * a, halfH };
  };
  const paneToUV = (x, y, w, hh) => {
    const d = uvDims(w, hh);
    return { u: ed.uvView.cx + (2 * x / w - 1) * d.halfW, v: ed.uvView.cy - (2 * y / hh - 1) * d.halfH };
  };

  ed._drawHUD = () => {
    const hud = ui.hudCanvas;
    const ctx = hud.getContext('2d');
    const dpr = ed.dpr;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, hud.width / dpr, hud.height / dpr);
    const p3 = ui.pane3d, pu = ui.paneUV;
    if (!p3.classList.contains('tp-hidden') && p3.offsetWidth > 2) {
      const ox = p3.offsetLeft, oy = p3.offsetTop, w = p3.offsetWidth, hh = p3.offsetHeight;
      ctx.save();
      ctx.beginPath(); ctx.rect(ox, oy, w, hh); ctx.clip();
      if (st.capture.frame && ed.hasModel) {
        const fr = ed.frameRect(w, hh);
        ctx.fillStyle = 'rgba(0,0,0,0.38)';
        ctx.beginPath();
        ctx.rect(ox, oy, w, hh);
        ctx.rect(ox + fr.x + fr.w, oy + fr.y, -fr.w, fr.h);
        ctx.fill('evenodd');
        ctx.strokeStyle = 'rgba(255,255,255,0.75)';
        ctx.setLineDash([6, 4]);
        ctx.lineWidth = 1;
        ctx.strokeRect(ox + fr.x + 0.5, oy + fr.y + 0.5, fr.w - 1, fr.h - 1);
        ctx.setLineDash([]);
        const [cw, ch] = ed.captureSize();
        ctx.fillStyle = 'rgba(255,255,255,0.85)';
        ctx.font = '10px system-ui, sans-serif';
        ctx.fillText(`${cw} x ${ch}`, ox + fr.x + 6, oy + fr.y + fr.h - 6);
      }
      if (ed.hover && ed.hover.pane === '3d' && st.tool !== 'nav' && !ed.spaceDown && ed.hasModel) {
        const t = curTool();
        const r = Math.max(1, t.size * 0.5);
        const cx = ox + ed.hover.x, cy = oy + ed.hover.y;
        ctx.lineWidth = 1.5;
        ctx.strokeStyle = st.tool === 'erase' ? 'rgba(90,200,255,0.95)' : 'rgba(255,90,220,0.95)';
        ctx.beginPath(); ctx.arc(cx, cy, r, 0, Math.PI * 2); ctx.stroke();
        if (t.hardness > 0.02 && t.hardness < 0.98) {
          ctx.lineWidth = 1; ctx.setLineDash([3, 3]);
          ctx.beginPath(); ctx.arc(cx, cy, r * t.hardness, 0, Math.PI * 2); ctx.stroke();
          ctx.setLineDash([]);
        }
      }
      ctx.restore();
    }
    if (!pu.classList.contains('tp-hidden') && pu.offsetWidth > 2) {
      const ox = pu.offsetLeft, oy = pu.offsetTop, w = pu.offsetWidth, hh = pu.offsetHeight;
      ctx.save();
      ctx.beginPath(); ctx.rect(ox, oy, w, hh); ctx.clip();
      let uvp = null;
      if (ed.hoverUV) uvp = ed.hoverUV;
      else if (ed.hover && ed.hover.pane === 'uv') uvp = paneToUV(ed.hover.x, ed.hover.y, w, hh);
      if (uvp) {
        const d = uvDims(w, hh);
        const x = ox + ((uvp.u - ed.uvView.cx) / d.halfW * 0.5 + 0.5) * w;
        const y = oy + (1 - ((uvp.v - ed.uvView.cy) / d.halfH * 0.5 + 0.5)) * hh;
        ctx.strokeStyle = 'rgba(255,255,255,0.9)';
        ctx.lineWidth = 1;
        ctx.beginPath(); ctx.moveTo(x - 9, y); ctx.lineTo(x + 9, y); ctx.moveTo(x, y - 9); ctx.lineTo(x, y + 9); ctx.stroke();
        ctx.beginPath(); ctx.arc(x, y, 5, 0, Math.PI * 2); ctx.stroke();
        ctx.fillStyle = 'rgba(255,255,255,0.8)';
        ctx.font = '10px system-ui, sans-serif';
        ctx.fillText(`u ${uvp.u.toFixed(3)}  v ${uvp.v.toFixed(3)}`, ox + 8, oy + hh - 8);
      }
      ctx.restore();
    }
  };

  // =========================================================================================
  // buttons
  // =========================================================================================
  const B = ui.btn;
  const modelInput = h('input'); modelInput.type = 'file'; modelInput.accept = SUPPORTED_EXT.map((e) => '.' + e).join(','); modelInput.style.display = 'none';
  const texInput = h('input'); texInput.type = 'file'; texInput.accept = 'image/*'; texInput.style.display = 'none';
  ui.root.append(modelInput, texInput);

  ed.pickModelFile = async (file) => {
    const ext = extOf(file.name);
    if (!SUPPORTED_EXT.includes(ext)) { ed.log('error', `Unsupported model type ".${ext}". Use ${SUPPORTED_EXT.join(', ')}.`); ed.setStatus('Unsupported model type .' + ext, 'err'); return; }
    try {
      ed.setStatus('Reading ' + file.name + ' ...');
      const buf = await file.arrayBuffer();
      let name = file.name;
      if (ed.hooks.onModelPicked) name = (await ed.hooks.onModelPicked(file)) || name;
      await ed.loadModelBuffer(buf, name);
    } catch (e) { /* already logged */ }
  };

  B.bLoadModel.onclick = () => modelInput.click();
  modelInput.onchange = () => { const f = modelInput.files[0]; modelInput.value = ''; if (f) ed.pickModelFile(f); };
  B.bLoadTex.onclick = () => texInput.click();
  texInput.onchange = async () => {
    const f = texInput.files[0]; texInput.value = '';
    if (!f) return;
    try { await ed.loadTextureFile(f); } catch (e) { ed.log('error', 'Texture load failed', e); ed.setStatus('Texture load failed: ' + e.message, 'err'); }
  };
  B.bNewTex.onclick = () => {
    const ov = h('div');
    ov.style.cssText = 'position:absolute;inset:0;background:rgba(0,0,0,.55);z-index:20;display:flex;align-items:center;justify-content:center';
    const box = h('div');
    box.style.cssText = 'background:#1e2128;border:1px solid #333845;border-radius:8px;padding:14px 16px;min-width:250px';
    box.append(h('div', null, 'New blank texture'));
    box.firstChild.style.cssText = 'font-weight:600;margin-bottom:10px';
    const sel = h('select');
    for (const s of [1024, 2048, 4096]) { const o = h('option', null, `${s} x ${s}`); o.value = s; if (s === 2048) o.selected = true; sel.append(o); }
    const col = h('input'); col.type = 'color'; col.value = '#c8c8c8';
    const r1 = h('div', 'tp-row'); r1.append(h('span', 'tp-lbl', 'Size'), sel, h('span'));
    const r2 = h('div', 'tp-row'); r2.append(h('span', 'tp-lbl', 'Colour'), col, h('span'));
    const ok = makeButton('Create', null, 'tp-pri'), cancel = makeButton('Cancel');
    ok.onclick = () => { ed.newTexture(Number(sel.value), col.value); ov.remove(); };
    cancel.onclick = () => ov.remove();
    const row = h('div', 'tp-row2'); row.append(ok, cancel);
    box.append(r1, r2, row);
    ov.append(box);
    ui.root.append(ov);
  };
  B.bSaveTex.onclick = async () => { try { download(await ed.exportTextureBlob(), 'texture.png'); } catch (e) { ed.log('error', 'Texture export failed', e); } };
  ui.layout.onchange = () => { st.display.layout = ui.layout.value; ed._layoutPanes(); ed._dirty('settings'); };
  B.bSync.onclick = () => { if (ed.hooks.onSyncRequest) ed.hooks.onSyncRequest(); };
  B.bHelp.onclick = () => ui.help.classList.toggle('tp-show');
  B.tBrush.onclick = () => ed.setTool('brush');
  B.tErase.onclick = () => ed.setTool('erase');
  B.tNav.onclick = () => ed.setTool('nav');
  B.tUndo.onclick = () => ed.undo();
  B.tRedo.onclick = () => ed.redo();
  B.tFrameMask.onclick = () => ed.frameMask();
  B.tFrameModel.onclick = () => ed.frameModel();

  // fullscreen
  let placeholder = null;
  ed.setFullscreen = (on) => {
    if (on === !!ed.full) return;
    ed.full = on;
    if (on) {
      placeholder = document.createComment('texpaint');
      if (ed.root.parentNode) ed.root.parentNode.insertBefore(placeholder, ed.root);
      document.body.appendChild(ed.root);
      ed.root.classList.add('tp-full');
      B.bFull.textContent = 'Exit fullscreen';
    } else {
      ed.root.classList.remove('tp-full');
      if (placeholder && placeholder.parentNode) { placeholder.parentNode.insertBefore(ed.root, placeholder); placeholder.remove(); }
      B.bFull.textContent = 'Fullscreen';
    }
    ed.invalidate();
    ed.root.focus({ preventScroll: true });
  };
  B.bFull.onclick = () => ed.setFullscreen(!ed.full);

  // =========================================================================================
  // pointer / wheel / keyboard
  // =========================================================================================
  const local = (e, el) => {
    const r = el.getBoundingClientRect();
    const sx = el.offsetWidth / Math.max(1, r.width), sy = el.offsetHeight / Math.max(1, r.height);
    return { x: (e.clientX - r.left) * sx, y: (e.clientY - r.top) * sy, w: el.offsetWidth, h: el.offsetHeight };
  };
  const paintActive = () => st.tool !== 'nav' && !ed.spaceDown && ed.hasModel && ed.info && ed.info.hasUV;

  const p3 = ui.pane3d;
  p3.addEventListener('pointerdown', (e) => {
    ui.root.focus({ preventScroll: true });
    if (e.button !== 0 || !paintActive()) return;
    if (!ed.beginStroke(st.tool === 'erase')) return;
    try { p3.setPointerCapture(e.pointerId); } catch (_) { /* ignore */ }
    const p = local(e, p3);
    ed.strokeMove(p.x, p.y, e.pointerType === 'pen' ? e.pressure : 0);
    e.preventDefault();
  });
  p3.addEventListener('pointermove', (e) => {
    const p = local(e, p3);
    ed.hover = { x: p.x, y: p.y, pane: '3d' };
    ed.hudDirty = true;
    if (ed.stroke) {
      const evs = e.getCoalescedEvents ? e.getCoalescedEvents() : [e];
      for (const ev of evs.length ? evs : [e]) {
        const q = local(ev, p3);
        ed.strokeMove(q.x, q.y, ev.pointerType === 'pen' ? ev.pressure : 0);
      }
      return;
    }
    if (e.buttons === 0 && ed.hasModel && ed.info.triangles < 400000) {
      const now = performance.now();
      if (now - ed._lastRay > 70) {
        ed._lastRay = now;
        ed._syncCamera();
        ed.raycaster.setFromCamera(new THREE.Vector2((p.x / p.w) * 2 - 1, -((p.y / p.h) * 2 - 1)), ed.camera);
        const hit = ed.raycaster.intersectObject(ed.mesh, false)[0];
        ed.hoverUV = hit && hit.uv ? { u: hit.uv.x, v: hit.uv.y } : null;
      }
    }
  });
  const endStroke = (e) => { if (ed.stroke) { try { p3.releasePointerCapture(e.pointerId); } catch (_) { /* ignore */ } ed.endStroke(); } };
  p3.addEventListener('pointerup', endStroke);
  p3.addEventListener('pointercancel', endStroke);
  p3.addEventListener('pointerleave', () => { if (!ed.stroke) { ed.hover = null; ed.hoverUV = null; ed.hudDirty = true; } });
  p3.addEventListener('wheel', (e) => { e.stopPropagation(); }, { passive: true });
  p3.addEventListener('contextmenu', (e) => e.preventDefault());

  // ---- UV pane: pan / zoom
  const pu = ui.paneUV;
  let uvDrag = null;
  pu.addEventListener('pointerdown', (e) => {
    ui.root.focus({ preventScroll: true });
    const pan = e.button === 1 || e.button === 2 || (e.button === 0 && (st.tool === 'nav' || ed.spaceDown || true));
    if (!pan) return;
    const p = local(e, pu);
    uvDrag = { x: p.x, y: p.y, cx: ed.uvView.cx, cy: ed.uvView.cy };
    try { pu.setPointerCapture(e.pointerId); } catch (_) { /* ignore */ }
    e.preventDefault();
  });
  pu.addEventListener('pointermove', (e) => {
    const p = local(e, pu);
    ed.hover = { x: p.x, y: p.y, pane: 'uv' };
    ed.hoverUV = null;
    if (uvDrag) {
      const d = uvDims(p.w, p.h);
      ed.uvView.cx = uvDrag.cx - ((p.x - uvDrag.x) / p.w) * 2 * d.halfW;
      ed.uvView.cy = uvDrag.cy + ((p.y - uvDrag.y) / p.h) * 2 * d.halfH;
      ed.invalidate();
    }
    ed.hudDirty = true;
  });
  const uvEnd = (e) => { if (uvDrag) { uvDrag = null; try { pu.releasePointerCapture(e.pointerId); } catch (_) { /* ignore */ } } };
  pu.addEventListener('pointerup', uvEnd);
  pu.addEventListener('pointercancel', uvEnd);
  pu.addEventListener('pointerleave', () => { if (!uvDrag) { ed.hover = null; ed.hudDirty = true; } });
  pu.addEventListener('contextmenu', (e) => e.preventDefault());
  pu.addEventListener('wheel', (e) => {
    e.preventDefault();
    e.stopPropagation();
    const p = local(e, pu);
    const before = paneToUV(p.x, p.y, p.w, p.h);
    ed.uvView.zoom = Math.min(64, Math.max(0.25, ed.uvView.zoom * Math.pow(1.0018, -e.deltaY)));
    const after = paneToUV(p.x, p.y, p.w, p.h);
    ed.uvView.cx += before.u - after.u;
    ed.uvView.cy += before.v - after.v;
    ed.invalidate();
  }, { passive: false });

  // ---- keyboard
  const onKey = (e) => {
    const tag = (e.target && e.target.tagName) || '';
    if (tag === 'TEXTAREA' || (tag === 'INPUT' && e.target.type !== 'range' && e.target.type !== 'checkbox') || tag === 'SELECT') return;
    const k = e.key;
    const ctrl = e.ctrlKey || e.metaKey;
    let handled = true;
    if (ctrl && (k === 'z' || k === 'Z')) { if (e.shiftKey) ed.redo(); else ed.undo(); }
    else if (ctrl && (k === 'y' || k === 'Y')) ed.redo();
    else if (ctrl) handled = false;
    else if (k === 'b' || k === 'B') ed.setTool('brush');
    else if (k === 'e' || k === 'E') ed.setTool('erase');
    else if (k === 'n' || k === 'N') ed.setTool('nav');
    else if (k === 'x' || k === 'X') ed.setTool(st.tool === 'erase' ? 'brush' : 'erase');
    else if (k === '[') { const t = curTool(); t.size = Math.max(2, Math.round(t.size * 0.85)); ed._applyStateToUI(); ed.hudDirty = true; }
    else if (k === ']') { const t = curTool(); t.size = Math.min(400, Math.round(t.size / 0.85 + 1)); ed._applyStateToUI(); ed.hudDirty = true; }
    else if (k === 'f' || k === 'F') ed.frameMask();
    else if (k === 'Home') { ed.frameModel(); }
    else if (k === 'm' || k === 'M') { st.mask.show = !st.mask.show; ed._applyStateToUI(); ed.invalidate(); }
    else if (k === '1') { st.display.layout = 'split'; ed._applyStateToUI(); }
    else if (k === '2') { st.display.layout = '3d'; ed._applyStateToUI(); }
    else if (k === '3') { st.display.layout = 'uv'; ed._applyStateToUI(); }
    else if (k === 'Escape') { if (ed.full) ed.setFullscreen(false); else if (ui.help.classList.contains('tp-show')) ui.help.classList.remove('tp-show'); else handled = false; }
    else if (k === ' ') { if (!ed.spaceDown) { ed.spaceDown = true; ed._applyMouseButtons(); ed.hudDirty = true; } }
    else handled = false;
    if (handled) { e.preventDefault(); e.stopPropagation(); }
  };
  const onKeyUp = (e) => {
    if (e.key === ' ' && ed.spaceDown) { ed.spaceDown = false; ed._applyMouseButtons(); ed.hudDirty = true; e.stopPropagation(); }
  };
  ui.root.addEventListener('keydown', onKey);
  ui.root.addEventListener('keyup', onKeyUp);
  ui.root.addEventListener('blur', () => { if (ed.spaceDown) { ed.spaceDown = false; ed._applyMouseButtons(); } });

  // ---- drag and drop
  let dragDepth = 0;
  const stage = ui.stage;
  stage.addEventListener('dragenter', (e) => { e.preventDefault(); dragDepth++; ui.drop.classList.add('tp-show'); });
  stage.addEventListener('dragover', (e) => { e.preventDefault(); });
  stage.addEventListener('dragleave', () => { dragDepth = Math.max(0, dragDepth - 1); if (!dragDepth) ui.drop.classList.remove('tp-show'); });
  stage.addEventListener('drop', async (e) => {
    e.preventDefault(); e.stopPropagation();
    dragDepth = 0; ui.drop.classList.remove('tp-show');
    const f = e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0];
    if (!f) return;
    const ext = extOf(f.name);
    if (SUPPORTED_EXT.includes(ext)) await ed.pickModelFile(f);
    else if (IMG_EXT.includes(ext) || (f.type || '').startsWith('image/')) {
      try { await ed.loadTextureFile(f); } catch (err) { ed.log('error', 'Texture load failed', err); }
    } else ed.log('warn', `Dropped file type ".${ext}" is not supported.`);
  });

  // ---- resize
  ed._ro = new ResizeObserver(() => ed.invalidate());
  ed._ro.observe(ui.stage);
  ed._unbind = () => { ui.root.removeEventListener('keydown', onKey); ui.root.removeEventListener('keyup', onKeyUp); };
}
