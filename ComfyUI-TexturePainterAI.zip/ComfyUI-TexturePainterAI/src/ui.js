// DOM construction + CSS for the Texture Painter widget. No logic here - the editor wires events.

const CSS = /* css */ `
.tp-root{--bg:#17191e;--panel:#1e2128;--panel2:#252932;--line:#333845;--txt:#d9dde6;--dim:#8d94a5;--acc:#e24dd0;--acc2:#4da3ff;--ok:#4cc38a;--warn:#f0a23a;--err:#ef5b5b;
  position:relative;display:flex;flex-direction:column;width:100%;height:100%;min-height:360px;box-sizing:border-box;background:var(--bg);color:var(--txt);
  font:12px/1.35 system-ui,-apple-system,Segoe UI,Roboto,sans-serif;border:1px solid var(--line);border-radius:6px;overflow:hidden;outline:none;user-select:none;-webkit-user-select:none}
.tp-root *{box-sizing:border-box}
.tp-root.tp-full{position:fixed;inset:0;z-index:99999;border-radius:0;border:none}
.tp-top{display:flex;gap:6px;align-items:center;padding:5px 8px;background:var(--panel);border-bottom:1px solid var(--line);flex-wrap:wrap}
.tp-top .tp-sp{flex:1}
.tp-btn{background:var(--panel2);color:var(--txt);border:1px solid var(--line);border-radius:4px;padding:3px 9px;cursor:pointer;font:inherit;white-space:nowrap}
.tp-btn:hover{border-color:#5a6275;background:#2c313c}
.tp-btn:active{background:#343a47}
.tp-btn.tp-on{border-color:var(--acc);box-shadow:0 0 0 1px var(--acc) inset;color:#fff}
.tp-btn.tp-pri{background:#7a2a72;border-color:#a8399d}
.tp-btn.tp-pri:hover{background:#933489}
.tp-btn[disabled]{opacity:.45;cursor:default}
.tp-sel,.tp-root select{background:var(--panel2);color:var(--txt);border:1px solid var(--line);border-radius:4px;padding:2px 4px;font:inherit}
.tp-main{display:flex;flex:1;min-height:0}
.tp-tools{display:flex;flex-direction:column;gap:4px;padding:6px 4px;background:var(--panel);border-right:1px solid var(--line);width:52px;flex:none;align-items:stretch}
.tp-tools .tp-btn{padding:5px 0;text-align:center;font-size:11px;line-height:1.2}
.tp-tools .tp-ico{display:block;font-size:17px}
.tp-tools hr{border:none;border-top:1px solid var(--line);margin:3px 0;width:100%}
.tp-stage{position:relative;flex:1;min-width:0;background:#101216}
.tp-gl,.tp-hud{position:absolute;inset:0;width:100%;height:100%;display:block}
.tp-hud{pointer-events:none}
.tp-panes{position:absolute;inset:0;display:flex;gap:2px}
.tp-pane{position:relative;flex:1;min-width:0;min-height:0;touch-action:none}
.tp-pane.tp-hidden{display:none}
.tp-tag{position:absolute;left:8px;top:6px;font-size:10px;letter-spacing:.08em;color:#aab1c2;background:rgba(10,12,16,.55);padding:1px 6px;border-radius:3px;pointer-events:none}
.tp-side{width:262px;flex:none;overflow-y:auto;background:var(--panel);border-left:1px solid var(--line);padding:4px 0}
.tp-side details{border-bottom:1px solid var(--line)}
.tp-side summary{cursor:pointer;padding:6px 10px;font-weight:600;color:#c9cfdd;list-style:none}
.tp-side summary::before{content:"\\25B8";display:inline-block;width:12px;color:var(--dim)}
.tp-side details[open] summary::before{content:"\\25BE"}
.tp-sec{padding:2px 10px 8px}
.tp-row{display:grid;grid-template-columns:78px 1fr 40px;gap:6px;align-items:center;margin:3px 0}
.tp-row .tp-lbl{color:var(--dim)}
.tp-row .tp-val{text-align:right;color:var(--txt);font-variant-numeric:tabular-nums}
.tp-row input[type=range]{width:100%;margin:0;accent-color:var(--acc)}
.tp-row2{display:flex;gap:5px;flex-wrap:wrap;margin:4px 0;align-items:center}
.tp-row2 .tp-btn{flex:1 1 auto;padding:3px 6px}
.tp-chk{display:flex;gap:6px;align-items:center;margin:3px 0;color:var(--txt)}
.tp-note{color:var(--dim);font-size:11px;margin:3px 0}
.tp-banner{margin:6px 10px;padding:7px 8px;border:1px solid var(--acc);border-radius:5px;background:rgba(226,77,208,.09)}
.tp-banner.tp-hidden{display:none}
.tp-bottom{display:flex;gap:10px;align-items:center;padding:3px 8px;background:var(--panel);border-top:1px solid var(--line);color:var(--dim);font-size:11px;min-height:22px}
.tp-bottom .tp-msg{flex:1;min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.tp-bottom .tp-msg.tp-err{color:var(--err)}
.tp-bottom .tp-msg.tp-warn{color:var(--warn)}
.tp-bottom .tp-msg.tp-ok{color:var(--ok)}
.tp-log{height:110px;overflow:auto;background:#0f1115;border:1px solid var(--line);border-radius:4px;padding:4px 6px;font:11px/1.35 ui-monospace,Consolas,monospace;white-space:pre-wrap;user-select:text;-webkit-user-select:text;color:#b8bfcc}
.tp-log .e{color:var(--err)}.tp-log .w{color:var(--warn)}.tp-log .o{color:var(--ok)}
.tp-hist{display:flex;flex-direction:column;gap:3px;max-height:140px;overflow:auto}
.tp-hist .tp-btn{text-align:left}
.tp-drop{position:absolute;inset:0;display:none;align-items:center;justify-content:center;background:rgba(77,163,255,.15);border:2px dashed var(--acc2);color:#fff;font-size:16px;pointer-events:none;z-index:5}
.tp-drop.tp-show{display:flex}
.tp-empty{position:absolute;inset:0;display:flex;flex-direction:column;gap:8px;align-items:center;justify-content:center;color:var(--dim);pointer-events:none;text-align:center;padding:20px}
.tp-empty b{color:#c9cfdd;font-size:14px}
.tp-help{position:absolute;right:10px;top:10px;z-index:6;max-width:330px;background:rgba(18,20,26,.96);border:1px solid var(--line);border-radius:6px;padding:8px 12px;display:none}
.tp-help.tp-show{display:block}
.tp-help kbd{background:#2c313c;border:1px solid #444b5b;border-radius:3px;padding:0 4px;font:11px ui-monospace,Consolas,monospace}
`;

let cssInjected = false;
export function injectCSS() {
  if (cssInjected || typeof document === 'undefined') return;
  const s = document.createElement('style');
  s.setAttribute('data-texpaint', '1');
  s.textContent = CSS;
  document.head.appendChild(s);
  cssInjected = true;
}

export function h(tag, cls, text, attrs) {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (text != null) e.textContent = text;
  if (attrs) for (const k in attrs) e.setAttribute(k, attrs[k]);
  return e;
}

export function makeSlider(label, { min, max, step = 1, value, fmt }, onInput) {
  const row = h('div', 'tp-row');
  const lab = h('span', 'tp-lbl', label);
  const inp = h('input');
  inp.type = 'range';
  inp.min = min; inp.max = max; inp.step = step; inp.value = value;
  const val = h('span', 'tp-val');
  const f = fmt || ((v) => String(v));
  const upd = () => { val.textContent = f(Number(inp.value)); };
  inp.addEventListener('input', () => { upd(); onInput && onInput(Number(inp.value)); });
  upd();
  row.append(lab, inp, val);
  return {
    el: row,
    get: () => Number(inp.value),
    set: (v) => { inp.value = v; upd(); },
  };
}

export function makeCheck(label, value, onChange) {
  const l = h('label', 'tp-chk');
  const c = h('input');
  c.type = 'checkbox'; c.checked = !!value;
  c.addEventListener('change', () => onChange && onChange(c.checked));
  l.append(c, h('span', null, label));
  return { el: l, get: () => c.checked, set: (v) => { c.checked = !!v; } };
}

export function makeSection(title, open = true) {
  const d = h('details');
  if (open) d.open = true;
  d.append(h('summary', null, title));
  const body = h('div', 'tp-sec');
  d.append(body);
  return { el: d, body };
}

export function makeButton(text, title, cls) {
  const b = h('button', 'tp-btn' + (cls ? ' ' + cls : ''), text);
  b.type = 'button';
  if (title) b.title = title;
  return b;
}

/** Builds the full widget DOM. Returns references; wiring is done by the editor. */
export function buildUI() {
  injectCSS();
  const root = h('div', 'tp-root', null, { tabindex: '0' });

  // ---- top bar
  const top = h('div', 'tp-top');
  const bLoadModel = makeButton('Load model', 'Load a UV-unwrapped .glb / .gltf / .obj / .fbx (or drop a file on the viewport)');
  const bLoadTex = makeButton('Load texture', 'Load a PNG/JPG texture (UV map image)');
  const bNewTex = makeButton('New texture', 'Create a blank texture');
  const bSaveTex = makeButton('Save texture', 'Download the current texture as PNG');
  const layout = h('select', 'tp-sel', null, { title: 'Layout (keys 1 / 2 / 3)' });
  for (const [v, t] of [['split', 'Split 3D | UV'], ['3d', '3D only'], ['uv', 'UV only']]) { const o = h('option', null, t); o.value = v; layout.append(o); }
  const bSync = makeButton('Sync', 'Capture the current view now and store it for the workflow (also happens automatically on Queue)');
  const bFull = makeButton('Fullscreen', 'Toggle fullscreen (Esc to leave)');
  const bHelp = makeButton('?', 'Shortcuts');
  const spacer = h('span', 'tp-sp');
  top.append(bLoadModel, bLoadTex, bNewTex, bSaveTex, layout, spacer, bSync, bFull, bHelp);

  // ---- tool column
  const tools = h('div', 'tp-tools');
  const mkTool = (ico, txt, title) => { const b = makeButton('', title); b.innerHTML = `<span class="tp-ico">${ico}</span>${txt}`; return b; };
  const tBrush = mkTool('\u{1F58C}', 'Brush', 'Paint mask (B)');
  const tErase = mkTool('\u{1F9FD}', 'Erase', 'Erase mask (E)');
  const tNav = mkTool('\u{1F9ED}', 'Orbit', 'Navigate only (N) - hold Space for temporary orbit');
  const tUndo = mkTool('↩', 'Undo', 'Undo (Ctrl+Z)');
  const tRedo = mkTool('↪', 'Redo', 'Redo (Ctrl+Y)');
  const tFrameMask = mkTool('◎', 'Mask', 'Frame the painted mask (F)');
  const tFrameModel = mkTool('⌂', 'Model', 'Frame the whole model (Home)');
  tools.append(tBrush, tErase, tNav, h('hr'), tUndo, tRedo, h('hr'), tFrameMask, tFrameModel);

  // ---- stage
  const stage = h('div', 'tp-stage');
  const glCanvas = h('canvas', 'tp-gl');
  const panes = h('div', 'tp-panes');
  const pane3d = h('div', 'tp-pane');
  const paneUV = h('div', 'tp-pane');
  pane3d.append(h('span', 'tp-tag', '3D VIEW'));
  paneUV.append(h('span', 'tp-tag', 'UV MAP'));
  panes.append(pane3d, paneUV);
  const hudCanvas = h('canvas', 'tp-hud');
  const drop = h('div', 'tp-drop', 'Drop a .glb / .gltf / .obj / .fbx model or a texture image here');
  const empty = h('div', 'tp-empty');
  empty.innerHTML = '<b>No model loaded</b><span>Click <i>Load model</i> or drop a UV-unwrapped<br>.glb / .gltf / .obj / .fbx file on this area.</span>';
  const help = h('div', 'tp-help');
  help.innerHTML = '<b>Shortcuts</b><br><kbd>B</kbd> brush &nbsp;<kbd>E</kbd> eraser &nbsp;<kbd>N</kbd> orbit<br>' +
    '<kbd>X</kbd> swap brush/eraser &nbsp;<kbd>[</kbd> <kbd>]</kbd> size<br>' +
    '<kbd>Ctrl</kbd>+<kbd>Z</kbd> / <kbd>Ctrl</kbd>+<kbd>Y</kbd> undo / redo<br>' +
    '<kbd>F</kbd> frame mask &nbsp;<kbd>Home</kbd> frame model<br>' +
    '<kbd>M</kbd> show/hide mask &nbsp;<kbd>1</kbd><kbd>2</kbd><kbd>3</kbd> layouts<br>' +
    '<kbd>Space</kbd> hold = orbit with left mouse<br>' +
    'Middle mouse = orbit, right mouse = pan, wheel = zoom.<br>' +
    'UV map: wheel = zoom, middle/right/Space-drag = pan, <kbd>Home</kbd> = fit.<br>' +
    '<span style="color:#f0a23a">Orange</span> mask = seen at a grazing angle, will bake poorly from this camera.';
  stage.append(glCanvas, panes, hudCanvas, empty, drop, help);

  // ---- side panel
  const side = h('div', 'tp-side');

  const secBrush = makeSection('Brush');
  const secMask = makeSection('Mask');
  const secCap = makeSection('Capture / generation view');
  const secDisp = makeSection('Display', false);
  const secRes = makeSection('Result');
  const secHist = makeSection('Texture history', false);
  const secLog = makeSection('Log', false);
  side.append(secBrush.el, secMask.el, secCap.el, secDisp.el, secRes.el, secHist.el, secLog.el);

  const banner = h('div', 'tp-banner tp-hidden');
  side.insertBefore(banner, secBrush.el);

  const logEl = h('div', 'tp-log');
  const bCopyLog = makeButton('Copy log');
  const bClearLog = makeButton('Clear');
  const logRow = h('div', 'tp-row2');
  logRow.append(bCopyLog, bClearLog);
  secLog.body.append(logEl, logRow);

  const histEl = h('div', 'tp-hist');
  secHist.body.append(histEl);

  // ---- bottom
  const bottom = h('div', 'tp-bottom');
  const msg = h('span', 'tp-msg', 'Ready.');
  const stats = h('span', 'tp-stats', '');
  const syncState = h('span', 'tp-sync', '');
  bottom.append(msg, syncState, stats);

  const main = h('div', 'tp-main');
  main.append(tools, stage, side);
  root.append(top, main, bottom);

  return {
    root, top, main, stage, glCanvas, hudCanvas, pane3d, paneUV, side, panes, empty, drop, help, banner,
    msg, stats, syncState, logEl, histEl,
    btn: { bLoadModel, bLoadTex, bNewTex, bSaveTex, bSync, bFull, bHelp, tBrush, tErase, tNav, tUndo, tRedo, tFrameMask, tFrameModel, bCopyLog, bClearLog },
    layout,
    sec: { brush: secBrush, mask: secMask, cap: secCap, disp: secDisp, res: secRes, hist: secHist },
  };
}
