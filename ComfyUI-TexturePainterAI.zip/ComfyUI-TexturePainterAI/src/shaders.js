// GLSL snippets used by the Texture Painter editor.
// Colour handling: every texture is treated as RAW bytes (NoColorSpace) and shaders never convert,
// so texels in the PNGs that are exported / baked are exactly what is displayed.

export const FULLSCREEN_VERT = /* glsl */ `
varying vec2 vUv;
void main() {
  vUv = uv;
  gl_Position = vec4(position.xy, 0.0, 1.0);
}`;

export const COPY_FRAG = /* glsl */ `
precision highp float;
uniform sampler2D tSrc;
varying vec2 vUv;
void main() { gl_FragColor = texture2D(tSrc, vUv); }`;

// Copies the red channel into an RGBA target as grey (used to read the R8 mask back).
export const COPY_GREY_FRAG = /* glsl */ `
precision highp float;
uniform sampler2D tSrc;
varying vec2 vUv;
void main() { float r = texture2D(tSrc, vUv).r; gl_FragColor = vec4(r, r, r, 1.0); }`;

export const INVERT_FRAG = /* glsl */ `
precision highp float;
uniform sampler2D tSrc;
varying vec2 vUv;
void main() { float r = 1.0 - texture2D(tSrc, vUv).r; gl_FragColor = vec4(r, r, r, 1.0); }`;

export const FILL_FRAG = /* glsl */ `
precision highp float;
void main() { gl_FragColor = vec4(1.0); }`;

// Separable max / min / box-blur. uMode: 0 = dilate (max), 1 = erode (min), 2 = box blur
export const MORPH_FRAG = /* glsl */ `
precision highp float;
uniform sampler2D tSrc;
uniform vec2 uStep;
uniform float uR;
uniform float uMode;
varying vec2 vUv;
void main() {
  float acc = uMode < 0.5 ? 0.0 : (uMode < 1.5 ? 1.0 : 0.0);
  float cnt = 0.0;
  for (int i = -64; i <= 64; i++) {
    float fi = float(i);
    if (abs(fi) > uR) continue;
    float v = texture2D(tSrc, vUv + uStep * fi).r;
    if (uMode < 0.5) acc = max(acc, v);
    else if (uMode < 1.5) acc = min(acc, v);
    else { acc += v; cnt += 1.0; }
  }
  if (uMode > 1.5) acc /= max(cnt, 1.0);
  gl_FragColor = vec4(acc, acc, acc, 1.0);
}`;

// ---------------------------------------------------------------------------------------------
// Display material for the 3D view
// ---------------------------------------------------------------------------------------------
export const MESH_VERT = /* glsl */ `
varying vec2 vUv;
varying vec3 vN;
varying vec3 vW;
void main() {
  vUv = uv;
  vN = normal;
  vW = position;
  gl_Position = projectionMatrix * viewMatrix * vec4(position, 1.0);
}`;

export const MESH_FRAG = /* glsl */ `
precision highp float;
uniform sampler2D tColor;
uniform sampler2D tMask;
uniform vec3 uMaskColor;
uniform float uMaskOpacity;
uniform float uShowMask;
uniform float uShade;
uniform float uFacingThr;
varying vec2 vUv;
varying vec3 vN;
varying vec3 vW;
void main() {
  vec3 n = normalize(vN);
  vec3 v = normalize(cameraPosition - vW);
  float f = abs(dot(n, v));
  vec3 col = texture2D(tColor, vUv).rgb;
  col *= mix(1.0, 0.30 + 0.70 * f, uShade);
  float m = texture2D(tMask, vUv).r * uShowMask;
  // orange = masked but seen at a grazing angle -> will bake poorly from this camera
  vec3 mc = mix(vec3(1.0, 0.55, 0.10), uMaskColor, smoothstep(uFacingThr, uFacingThr + 0.25, f));
  col = mix(col, mc, m * uMaskOpacity);
  gl_FragColor = vec4(col, 1.0);
}`;

// ---------------------------------------------------------------------------------------------
// Display material for the UV view (a quad covering [0,1]^2)
// ---------------------------------------------------------------------------------------------
export const UVQUAD_VERT = /* glsl */ `
varying vec2 vUv;
void main() {
  vUv = uv;
  gl_Position = projectionMatrix * viewMatrix * vec4(position, 1.0);
}`;

export const UVQUAD_FRAG = /* glsl */ `
precision highp float;
uniform sampler2D tColor;
uniform sampler2D tMask;
uniform vec3 uMaskColor;
uniform float uMaskOpacity;
uniform float uShowMask;
uniform float uChecker;
varying vec2 vUv;
void main() {
  vec3 col = texture2D(tColor, vUv).rgb;
  float m = texture2D(tMask, vUv).r * uShowMask;
  col = mix(col, uMaskColor, m * uMaskOpacity);
  gl_FragColor = vec4(col, 1.0);
}`;

// ---------------------------------------------------------------------------------------------
// Projective brush: stamps a screen-space brush into UV space.
// The mesh is drawn with gl_Position = uv, so every visible texel under the brush is written
// directly into the mask (view independent, seam safe, no readbacks).
// ---------------------------------------------------------------------------------------------
export const PAINT_VERT = /* glsl */ `
varying vec3 vW;
varying vec3 vN;
void main() {
  vW = position;
  vN = normal;
  gl_Position = vec4(uv * 2.0 - 1.0, 0.0, 1.0);
}`;

export const PAINT_FRAG = /* glsl */ `
precision highp float;
uniform mat4 uVP;
uniform vec3 uCam;
uniform vec2 uCenter;     // brush centre in pixels, origin bottom-left
uniform vec2 uSize;       // viewport size in pixels
uniform float uRadius;    // brush radius in pixels
uniform float uHardness;  // 0..1  size of the fully opaque core
uniform float uSoft;      // 0..1  0 = linear ramp, 1 = smooth (ease) ramp
uniform float uOpacity;
uniform sampler2D uDepth;
uniform float uNear;
uniform float uFar;
uniform float uBias;
uniform float uFacingMin;
varying vec3 vW;
varying vec3 vN;

float linZ(float d) {
  float z = d * 2.0 - 1.0;
  return 2.0 * uNear * uFar / (uFar + uNear - z * (uFar - uNear));
}

void main() {
  vec4 clip = uVP * vec4(vW, 1.0);
  if (clip.w <= 0.0) discard;
  vec3 ndc = clip.xyz / clip.w;
  if (abs(ndc.x) > 1.0 || abs(ndc.y) > 1.0 || abs(ndc.z) > 1.0) discard;
  vec2 px = (ndc.xy * 0.5 + 0.5) * uSize;
  float d = length(px - uCenter) / uRadius;
  if (d > 1.0) discard;
  float f = abs(dot(normalize(vN), normalize(uCam - vW)));
  if (f < uFacingMin) discard;
  float sd = texture2D(uDepth, ndc.xy * 0.5 + 0.5).x;
  float fd = ndc.z * 0.5 + 0.5;
  if (linZ(fd) > linZ(sd) + uBias * (1.0 + 4.0 * (1.0 - f))) discard;
  float t = clamp((d - uHardness) / max(1.0 - uHardness, 0.001), 0.0, 1.0);
  float e = 1.0 - t;
  float a = mix(e, e * e * (3.0 - 2.0 * e), uSoft) * uOpacity;
  gl_FragColor = vec4(a, a, a, a);
}`;

// ---------------------------------------------------------------------------------------------
// Render passes used for the capture (sent to the Python side).
// uMode: 0 colour, 1 packed linear depth, 2 view-space normal, 3 UV mask, 4 silhouette
// ---------------------------------------------------------------------------------------------
export const PASS_VERT = /* glsl */ `
varying vec2 vUv;
varying vec3 vN;
varying vec3 vVP;
void main() {
  vUv = uv;
  vN = normal;
  vec4 vp = viewMatrix * vec4(position, 1.0);
  vVP = vp.xyz;
  gl_Position = projectionMatrix * vp;
}`;

export const PASS_FRAG = /* glsl */ `
precision highp float;
uniform sampler2D tColor;
uniform sampler2D tMask;
uniform float uMode;
uniform float uShade;
uniform float uNear;
uniform float uFar;
varying vec2 vUv;
varying vec3 vN;
varying vec3 vVP;
void main() {
  vec3 n = normalize(vN);
  if (uMode < 0.5) {
    vec3 v = normalize(-vVP);
    vec3 nv = normalize((viewMatrix * vec4(n, 0.0)).xyz);
    float f = abs(dot(nv, v));
    vec3 col = texture2D(tColor, vUv).rgb;
    col *= mix(1.0, 0.30 + 0.70 * f, uShade);
    gl_FragColor = vec4(col, 1.0);
  } else if (uMode < 1.5) {
    float t = clamp((-vVP.z - uNear) / (uFar - uNear), 0.0, 1.0);
    float v = floor(t * 16777215.0 + 0.5);
    float r = floor(v / 65536.0);
    float g = floor((v - r * 65536.0) / 256.0);
    float b = v - r * 65536.0 - g * 256.0;
    gl_FragColor = vec4(r / 255.0, g / 255.0, b / 255.0, 1.0);
  } else if (uMode < 2.5) {
    vec3 nv = normalize((viewMatrix * vec4(n, 0.0)).xyz);
    if (nv.z < 0.0) nv = -nv;
    gl_FragColor = vec4(nv * 0.5 + 0.5, 1.0);
  } else if (uMode < 3.5) {
    float m = texture2D(tMask, vUv).r;
    gl_FragColor = vec4(m, m, m, 1.0);
  } else {
    gl_FragColor = vec4(1.0);
  }
}`;

export const DEPTH_ONLY_FRAG = /* glsl */ `
precision highp float;
void main() { gl_FragColor = vec4(1.0); }`;

export const DEPTH_ONLY_VERT = /* glsl */ `
void main() { gl_Position = projectionMatrix * viewMatrix * vec4(position, 1.0); }`;
