// Full-stack test: real editor bundle + glue (texpaint.js) + real HTTP routes + real Python nodes.
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import puppeteer from 'puppeteer-core';

const here = path.dirname(fileURLToPath(import.meta.url));
const out = path.resolve(process.argv[2] || '/tmp/tp_e2e');
fs.mkdirSync(out, { recursive: true });

const srv = spawn('python3', [path.join(here, 'e2e_server.py')], { stdio: ['ignore', 'pipe', 'pipe'] });
let srvErr = '';
srv.stderr.on('data', (d) => { srvErr += d.toString(); });
const port = await new Promise((res, rej) => {
  let buf = '';
  srv.stdout.on('data', (d) => { buf += d.toString(); const m = /PORT (\d+)/.exec(buf); if (m) res(Number(m[1])); });
  srv.on('exit', (c) => rej(new Error('server exited early: ' + srvErr)));
  setTimeout(() => rej(new Error('server start timeout: ' + srvErr)), 20000);
});

const browser = await puppeteer.launch({
  executablePath: '/usr/bin/google-chrome', headless: 'new',
  args: ['--no-sandbox', '--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist', '--window-size=1300,820'],
});
const page = await browser.newPage();
await page.setViewport({ width: 1300, height: 820 });
const logs = [];
page.on('console', (m) => { if (!/GPU stall/.test(m.text())) logs.push(`[${m.type()}] ${m.text()}`); });
page.on('pageerror', (e) => logs.push(`[pageerror] ${e.stack || e.message}`));

let failed = false;
try {
  await page.goto(`http://127.0.0.1:${port}/tests/e2e.html`);
  await page.waitForFunction('window.ready === true', { timeout: 20000 });

  const R = await page.evaluate(async () => {
    const R = {};
    const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
    const waitFor = async (fn, ms = 20000) => { const t0 = performance.now(); while (performance.now() - t0 < ms) { if (await fn()) return true; await sleep(100); } return false; };

    const node = await window.makeNode();
    const rec = window.TexturePainterAI.records.get(node.id);
    const ed = rec.ed;
    R.stateWidget = node.widgets.find((w) => w.name === 'state_json').value;
    R.hiddenState = node.widgets.find((w) => w.name === 'state_json').hidden === true;
    R.domWidgetFirst = node.widgets[0].name === 'texpaint_view';

    // ---- cube + atlas (same as browser_test)
    const faces = [
      { n: [0, 0, 1], v: [[-1, -1, 1], [1, -1, 1], [1, 1, 1], [-1, 1, 1]] }, { n: [0, 0, -1], v: [[1, -1, -1], [-1, -1, -1], [-1, 1, -1], [1, 1, -1]] },
      { n: [1, 0, 0], v: [[1, -1, 1], [1, -1, -1], [1, 1, -1], [1, 1, 1]] }, { n: [-1, 0, 0], v: [[-1, -1, -1], [-1, -1, 1], [-1, 1, 1], [-1, 1, -1]] },
      { n: [0, 1, 0], v: [[-1, 1, 1], [1, 1, 1], [1, 1, -1], [-1, 1, -1]] }, { n: [0, -1, 0], v: [[-1, -1, -1], [1, -1, -1], [1, -1, 1], [-1, -1, 1]] },
    ];
    let obj = '', vi = 1;
    faces.forEach((f, i) => {
      const col = i % 3, row = Math.floor(i / 3), m = 0.01;
      const u0 = col / 3 + m, u1 = (col + 1) / 3 - m, v0 = row / 2 + m, v1 = (row + 1) / 2 - m;
      const uvs = [[u0, v0], [u1, v0], [u1, v1], [u0, v1]];
      for (let k = 0; k < 4; k++) obj += `v ${f.v[k].join(' ')}\nvt ${uvs[k].join(' ')}\nvn ${f.n.join(' ')}\n`;
      const a = vi, b = vi + 1, c = vi + 2, d = vi + 3;
      obj += `f ${a}/${a}/${a} ${b}/${b}/${b} ${c}/${c}/${c}\nf ${a}/${a}/${a} ${c}/${c}/${c} ${d}/${d}/${d}\n`;
      vi += 4;
    });
    // model goes through the real upload route
    await ed.pickModelFile(new File([obj], 'my cube.obj'));
    R.modelName = ed.state.model && ed.state.model.name;
    R.tris = ed.info && ed.info.triangles;

    const c = document.createElement('canvas'); c.width = c.height = 1024;
    const g = c.getContext('2d');
    g.fillStyle = '#303030'; g.fillRect(0, 0, 1024, 1024);
    const colors = ['#e03030', '#30c8c8', '#30c040', '#c030c0', '#3050e0', '#e0d030'];
    faces.forEach((f, i) => { const col = i % 3, row = Math.floor(i / 3); g.fillStyle = colors[i]; g.fillRect(col * 1024 / 3, 1024 * (1 - (row + 1) / 2), 1024 / 3, 512); });
    ed.setTextureFromImage(c, { label: 'test', keepHistory: false });
    ed.frameModel();
    await sleep(300);

    // ---- paint
    ed.state.brush.size = 240;
    const p3 = ed.ui.pane3d;
    ed.beginStroke(false); ed.strokeMove(p3.offsetWidth / 2, p3.offsetHeight / 2, 0); ed.strokeMove(p3.offsetWidth / 2 + 40, p3.offsetHeight / 2 + 10, 0); ed.endStroke();
    R.maskedBefore = (() => { const b = ed._readMaskPixels(); let s = 0; for (let i = 0; i < b.length; i += 4) s += b[i]; return s; })();
    const maskBefore = ed._readMaskPixels().slice();
    const before = document.createElement('canvas'); before.width = ed.texCanvas.width; before.height = ed.texCanvas.height; before.getContext('2d').drawImage(ed.texCanvas, 0, 0);

    // ---- "Queue prompt": the glue must commit the view first
    R.queuedBefore = window.__queued || 0;
    await window.app.queuePrompt();
    R.queuedAfter = window.__queued;
    R.syncedLabel = ed.ui.syncState.textContent;
    R.stateAfterCommit = node.widgets.find((w) => w.name === 'state_json').value;
    const t0 = performance.now();
    await window.app.queuePrompt();           // nothing changed -> must be skipped (fast, same commit)
    R.secondQueueMs = Math.round(performance.now() - t0);

    // ---- server runs Painter -> (fake generator) -> Bake
    const resp = await fetch('/__run', { method: 'POST', body: JSON.stringify({ session: rec.sid }) });
    R.runStatus = resp.status;
    const rj = await resp.json();
    R.runReport = rj.report || rj.error;
    R.gotResult = await waitFor(() => !!ed.pending);
    R.bannerVisible = !ed.ui.banner.classList.contains('tp-hidden');
    R.compareShowing = ed.compare;
    await sleep(400);
    window.__shotReady = true;
    R.pendingStats = ed.pending && ed.pending.stats;

    // ---- apply
    ed.applyResult();
    await sleep(200);
    R.maskedAfter = (() => { const b = ed._readMaskPixels(); let s = 0; for (let i = 0; i < b.length; i += 4) s += b[i]; return s; })();
    const after = ed.texCanvas;
    const a = before.getContext('2d').getImageData(0, 0, 1024, 1024).data, b2 = after.getContext('2d').getImageData(0, 0, 1024, 1024).data;
    let changed = 0, greenish = 0;
    for (let i = 0; i < a.length; i += 4) {
      if (Math.abs(a[i] - b2[i]) + Math.abs(a[i + 1] - b2[i + 1]) + Math.abs(a[i + 2] - b2[i + 2]) > 30) { changed++; if (b2[i + 1] > b2[i] + 25 && b2[i + 1] > b2[i + 2] + 25) greenish++; }
    }
    R.changedTexels = changed; R.greenTexels = greenish;
    let outside = 0;
    { const W = 1024, mw = Math.round(Math.sqrt(maskBefore.length / 4));
      for (let i = 0; i < a.length; i += 4) {
        if (Math.abs(a[i] - b2[i]) + Math.abs(a[i + 1] - b2[i + 1]) + Math.abs(a[i + 2] - b2[i + 2]) > 30) {
          const px = (i / 4) % W, py = Math.floor(i / 4 / W);
                    // dilate check: any mask within 9px (padding)
          let near = false;
          for (let dy = -9; dy <= 9 && !near; dy += 3) for (let dx = -9; dx <= 9; dx += 3) {
            const yy = Math.min(mw - 1, Math.max(0, (mw - 1 - Math.floor(py * mw / W)) + dy)), xx = Math.min(mw - 1, Math.max(0, Math.floor(px * mw / W) + dx));
            if (maskBefore[(yy * mw + xx) * 4] > 0) { near = true; break; }
          }
          if (!near) outside++;
        }
      } }
    R.changedFarFromMask = outside;
    R.historyLen = ed.texHistory.length;
    ed.revertTexture(0);                         // revert must restore the old texture
    const rv = ed.texCanvas.getContext('2d').getImageData(0, 0, 1024, 1024).data;
    let diffRev = 0; for (let i = 0; i < a.length; i += 4) if (Math.abs(a[i] - rv[i]) > 2) diffRev++;
    R.revertDiff = diffRev;
    ed.applyResult && 0;

    // ---- duplicate the node (same state_json) -> clone route + restore
    const n2 = await window.makeNode();
    n2.properties = { texpaint_ui: JSON.parse(JSON.stringify(ed.getState())) };
    n2.widgets.find((w) => w.name === 'state_json').value = JSON.stringify({ session: rec.sid });
    window.__NT.prototype.onConfigure && window.__NT.prototype.onConfigure.call(n2);
    const rec2 = window.TexturePainterAI.records.get(n2.id);
    R.cloneNewSession = rec2.sid !== rec.sid;
    await waitFor(() => !rec2.restoring && rec2.ed.hasModel, 15000);
    R.restoredTris = rec2.ed.info && rec2.ed.info.triangles;
    R.restoredMaskNonEmpty = !rec2.ed.maskIsEmpty();
    R.logs = ed.logLines.slice(-8);
    return R;
  });

  await page.screenshot({ path: path.join(out, 'e2e_screenshot.png') });
  console.log(JSON.stringify(R, null, 1));
  const must = {
    'state widget hidden': R.hiddenState, 'viewport widget first': R.domWidgetFirst,
    'model uploaded + loaded': R.tris === 12 && /my cube_[0-9a-f]{8}\.obj/.test(R.modelName || ''),
    'glue committed before queue': R.queuedAfter === R.queuedBefore + 1 && R.syncedLabel.includes('synced'),
    'unchanged re-queue is skipped': R.secondQueueMs < 400,
    'server run ok': R.runStatus === 200,
    'result event received': R.gotResult && R.bannerVisible,
    'texels changed inside mask': R.changedTexels > 5000 && R.greenTexels > 0.7 * R.changedTexels && R.changedFarFromMask < 0.01 * R.changedTexels,
    'mask mostly cleared after apply': R.maskedAfter < 0.25 * R.maskedBefore,
    'texture history + revert': R.historyLen >= 1 && R.revertDiff === 0,
    'duplicate node cloned + restored': R.cloneNewSession && R.restoredTris === 12 && R.restoredMaskNonEmpty,
  };
  for (const [k, v] of Object.entries(must)) { console.log((v ? 'PASS ' : 'FAIL ') + k); if (!v) failed = true; }
} catch (e) {
  failed = true;
  console.log('TEST FAILURE:', e.stack || e);
  try { await page.screenshot({ path: path.join(out, 'failure.png') }); } catch (_) {}
}
console.log('--- browser console ---\n' + logs.join('\n'));
if (srvErr.trim()) console.log('--- server stderr (expected: none or intentional errors) ---\n' + srvErr.slice(-3000));
await browser.close();
srv.kill();
process.exit(failed ? 1 : 0);
