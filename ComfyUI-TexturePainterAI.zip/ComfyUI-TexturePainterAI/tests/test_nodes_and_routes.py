"""Exercises the real HTTP routes (aiohttp test client) and both nodes with stubbed ComfyUI modules."""
import asyncio, importlib.util, json, os, sys, tempfile
import numpy as np
from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
PKG = os.path.dirname(HERE)
OUT = sys.argv[1] if len(sys.argv) > 1 else "/tmp/tp_out"
os.environ["TEXPAINT_TEST_INPUT"] = tempfile.mkdtemp(prefix="tp_input_")
sys.path.insert(0, os.path.join(HERE, "stubs"))

spec = importlib.util.spec_from_file_location("tpkg", os.path.join(PKG, "__init__.py"), submodule_search_locations=[PKG])
tpkg = importlib.util.module_from_spec(spec)
sys.modules["tpkg"] = tpkg
spec.loader.exec_module(tpkg)
from tpkg import tp_nodes, tp_server, tp_common as C  # noqa: E402
from server import PromptServer  # noqa: E402  (stub)
from aiohttp import web, FormData  # noqa: E402
from aiohttp.test_utils import TestClient, TestServer  # noqa: E402

assert set(tpkg.NODE_CLASS_MAPPINGS) == {"TexturePainterAI", "TexturePainterAIBake"}, tpkg.NODE_CLASS_MAPPINGS
assert tpkg.WEB_DIRECTORY == "./web"

SID = "tp_test_session_01"


def commit_form(commit_id, with_mesh=True):
    fd = FormData()
    for k, f in [("view", "view.png"), ("viewmask", "viewmask.png"), ("depth", "depth.png"), ("normal", "normal.png"),
                 ("uvmask", "uvmask.png"), ("texture", "texture.png")]:
        fd.add_field(k, open(f"{OUT}/{f}", "rb").read(), filename=f, content_type="image/png")
    if with_mesh:
        fd.add_field("mesh", open(f"{OUT}/mesh.bin", "rb").read(), filename="mesh.bin", content_type="application/octet-stream")
    fd.add_field("meta", open(f"{OUT}/meta.json").read())
    fd.add_field("commit_id", commit_id)
    return fd


async def main():
    app = web.Application(client_max_size=200 * 1024 * 1024)
    app.add_routes(PromptServer.instance.routes)
    async with TestClient(TestServer(app)) as cl:
        r = await cl.get("/texpaint/ping"); assert r.status == 200, await r.text()

        # --- model upload / download
        fd = FormData(); fd.add_field("file", b"v 0 0 0\nv 1 0 0\nv 0 1 0\nf 1 2 3\n", filename="../../evil name.obj")
        r = await cl.post("/texpaint/upload_model", data=fd); j = await r.json(); assert r.status == 200, j
        name = j["name"]; assert "/" not in name and name.endswith(".obj"), name
        r = await cl.get(f"/texpaint/model/{name}"); assert r.status == 200 and (await r.read()).startswith(b"v 0")
        fd = FormData(); fd.add_field("file", b"x", filename="payload.exe")
        r = await cl.post("/texpaint/upload_model", data=fd); assert r.status == 400
        r = await cl.get("/texpaint/model/..%2Fsecret.obj"); assert r.status in (400, 404)
        r = await cl.get("/texpaint/models"); assert name in (await r.json())["models"]

        # --- commit
        r = await cl.post(f"/texpaint/commit/{SID}", data=commit_form("commitaaaa111")); j = await r.json()
        assert r.status == 200 and j["commit_id"] == "commitaaaa111", j
        fd = FormData(); fd.add_field("view", b"not a png", filename="view.png"); fd.add_field("meta", "{}")
        r = await cl.post(f"/texpaint/commit/{SID}", data=fd); assert r.status == 400
        fd = FormData(); fd.add_field("mesh", b"garbage-garbage", filename="mesh.bin")
        r = await cl.post(f"/texpaint/put/{SID}", data=fd); assert r.status == 400
        r = await cl.post("/texpaint/commit/..%2F..%2Fx", data=commit_form("c1")); assert r.status in (400, 404)

        # --- session file access rules
        r = await cl.get(f"/texpaint/session/{SID}/view.png"); assert r.status == 200
        r = await cl.get(f"/texpaint/session/{SID}/passwd"); assert r.status == 400
        r = await cl.get(f"/texpaint/session/bad/view.png"); assert r.status == 400
        r = await cl.get(f"/texpaint/session/{SID}/..%2F..%2Fview.png"); assert r.status in (400, 404)

        # --- painter node
        state = json.dumps({"session": SID})
        node = tp_nodes.TexturePainterAI()
        assert tp_nodes.TexturePainterAI.IS_CHANGED(state, mask_grow=6, mask_feather=4).startswith("commitaaaa111")
        outs = node.run(state, "weathered red brick wall", "flat albedo", True, "tint_color", "#ff00ff", 1.0, 6, 4)
        edit, view, vm, depth, normal, tex, umask, prompt, w, h, bake = outs
        print("painter outputs:", [getattr(o, "shape", o) for o in outs[:10]])
        assert edit.shape == (1, 1024, 1024, 3) and vm.shape == (1, 1024, 1024) and (w, h) == (1024, 1024)
        assert prompt.startswith("Repaint only the magenta marked area: weathered red brick wall.")
        assert edit[0][vm[0] > 0.9].mean(axis=0)[0] > 0.8, "tint not applied in masked area"
        assert np.allclose(edit[0][vm[0] < 0.001], view[0][vm[0] < 0.001]), "tint leaked outside mask"
        Image.fromarray((edit[0] * 255).astype(np.uint8)).save(f"{OUT}/node_edit_image.png")

        # --- bake node
        bn = tp_nodes.TexturePainterAIBake()
        gen = (1.0 - view)  # pretend the generator inverted the colours
        texture, conf, remaining, report = bn.run(bake, gen, -1.0, 0.003, 1.0, 8)
        print("bake report:", report.replace("\n", " | "))
        assert texture.shape == (1, 1024, 1024, 3) and conf.shape == (1, 1024, 1024)
        ev = [e for e in PromptServer.instance.events if e[0] == "texpaint.baked"]
        assert ev and ev[-1][1]["session"] == SID and ev[-1][1]["result"].startswith("result_")
        r = await cl.get(f"/texpaint/session/{SID}/{ev[-1][1]['result']}"); assert r.status == 200
        im = Image.open(__import__("io").BytesIO(await r.read())); assert im.size == (1024, 1024)
        r = await cl.get(f"/texpaint/session/{SID}/{ev[-1][1]['remaining']}"); assert r.status == 200
        Image.open(__import__("io").BytesIO(await r.read())).save(f"{OUT}/node_remaining.png")
        im.save(f"{OUT}/node_result.png")
        assert (conf > 0.5).sum() > 5000

        # aspect mismatch warns but works; wrong size generated image should still not crash
        gen2 = np.ascontiguousarray(gen[:, :, :512, :])
        _, _, _, rep2 = bn.run(bake, gen2, 0.3, 0.003, 1.0, 0)
        assert "aspect ratio" in rep2, rep2

        # --- stale commit protection
        r = await cl.post(f"/texpaint/commit/{SID}", data=commit_form("commitbbbb222", with_mesh=False)); assert r.status == 200
        try:
            bn.run(bake, gen, -1.0, 0.003, 1.0, 8)
            raise SystemExit("stale bake_data was accepted!")
        except RuntimeError as e:
            assert "changed after" in str(e), e
        # --- painter without capture
        try:
            node.run(json.dumps({"session": "tp_nothing_here"}), "x", "", True, "none", "#fff", 1, 0, 0)
            raise SystemExit("missing capture accepted")
        except RuntimeError as e:
            assert "No captured view" in str(e), e
    print("ALL NODE / ROUTE CHECKS PASSED")


asyncio.run(main())
