import os
def get_input_directory():
    return os.environ["TEXPAINT_TEST_INPUT"]
