"""Integration test: feeds the captures produced by the REAL browser editor (tests/browser_test.mjs)
into the Python baker and checks that texels land where they should (orientation, matrices, depth)."""
import json, os, sys, time
import numpy as np
from PIL import Image

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import tp_core as core

d = sys.argv[1] if len(sys.argv) > 1 else "/tmp/tp_out"
meta = json.load(open(f"{d}/meta.json"))
mesh = core.read_mesh_bin(open(f"{d}/mesh.bin", "rb").read())
tex = np.array(Image.open(f"{d}/texture.png").convert("RGB"))
H, W = tex.shape[:2]
uvm = np.array(Image.open(f"{d}/uvmask.png").convert("L")).astype(np.float32) / 255.0
if uvm.shape != (H, W):
    uvm = np.array(Image.fromarray((uvm * 255).astype(np.uint8)).resize((W, H), Image.BILINEAR)).astype(np.float32) / 255.0
depth = np.array(Image.open(f"{d}/depth.png").convert("RGB"))
view = np.array(Image.open(f"{d}/view.png").convert("RGB")).astype(np.float32)
print("mesh", mesh.positions.shape, mesh.indices.shape, "tex", tex.shape, "mask max", uvm.max(), "masked texels", int((uvm > 0.5).sum()))

t0 = time.time()
r = core.rasterize_uv(mesh, W, H)
print(f"rasterize {time.time()-t0:.2f}s covered={r.cov.sum()} overlap={r.overlap_ratio:.4f}")
expected_cover = 6 * (1 / 3 - 0.02) * (1 / 2 - 0.02) * W * H
assert abs(r.cov.sum() - expected_cover) / expected_cover < 0.02, (r.cov.sum(), expected_cover)
assert r.overlap_ratio < 0.001

cam = meta["camera"]

# ---- 1) identity: generated == view render  ->  texture must (almost) not change
t0 = time.time()
res = core.bake(mesh, r, cam, depth, view, uvm, tex, facing=meta["facing"], padding=8)
print(f"bake {time.time()-t0:.2f}s stats={res['stats']}")
new = res["texture"].astype(np.int32)
old = tex.astype(np.int32)
conf = res["confidence"]
sel = (conf > 0.95) & r.cov
print("identity: baked texels", int(sel.sum()), "mean abs diff", np.abs(new[sel] - old[sel]).mean())
assert sel.sum() > 5000, "nothing was baked"
assert np.abs(new[sel] - old[sel]).mean() < 6.0, "identity bake drifted -> projection/orientation mismatch"
outside = (uvm < 0.004) & r.cov
assert np.abs(new[outside] - old[outside]).max() == 0, "texels outside the mask changed"

# ---- 2) inverted generated image -> baked texels become the inverted texture colours
gen = 255.0 - view
res2 = core.bake(mesh, r, cam, depth, gen, uvm, tex, facing=meta["facing"], padding=8)
n2 = res2["texture"].astype(np.int32)
sel2 = (res2["confidence"] > 0.97) & r.cov
inv = 255 - old
err = np.abs(n2[sel2] - inv[sel2]).mean()
print("inverted: baked texels", int(sel2.sum()), "mean abs err vs inverted texture", err)
assert err < 8.0

# which face got painted? (+Z cell = col 0,row 0, i.e. bottom-left of the UV map)
cells = json.load(open(f"{d}/cells.json"))
for c in cells:
    x0 = int(c["col"] * W / 3); x1 = int((c["col"] + 1) * W / 3)
    y0 = int(H * (1 - (c["row"] + 1) / 2)); y1 = int(H * (1 - c["row"] / 2))
    print(f"  face {c['name']}: baked {(res2['confidence'][y0:y1, x0:x1] > 0.5).sum():7d} texels, masked {(uvm[y0:y1, x0:x1] > 0.5).sum():7d}")

# facing / visibility: faces the camera cannot see must stay untouched
for c in cells:
    if c["name"] in ("-Z", "-X", "-Y"):
        x0 = int(c["col"] * W / 3); x1 = int((c["col"] + 1) * W / 3)
        y0 = int(H * (1 - (c["row"] + 1) / 2)); y1 = int(H * (1 - c["row"] / 2))
        assert (res2["confidence"][y0:y1, x0:x1] > 0.01).sum() == 0, f"hidden face {c['name']} got baked"

# remaining mask must shrink
print("remaining mask area", float((res2["remaining"] > 0.5).sum()), "of", float((uvm > 0.5).sum()))
assert (res2["remaining"] > 0.5).sum() < (uvm > 0.5).sum()

# padding fallback (no scipy) must agree with the scipy path
core_nd = core._ndi
core._ndi = None
res3 = core.bake(mesh, r, cam, depth, gen, uvm, tex, facing=meta["facing"], padding=8)
core._ndi = core_nd
diff = np.abs(res3["texture"].astype(np.int32) - res2["texture"].astype(np.int32))
print("scipy vs numpy padding: max diff", diff.max(), "differing texels", int((diff.max(2) > 0).sum()))
assert (diff.max(2) > 8).sum() < 0.0005 * H * W

Image.fromarray(res2["texture"]).save(f"{d}/baked_inverted.png")
Image.fromarray((np.clip(res2["confidence"], 0, 1) * 255).astype(np.uint8)).save(f"{d}/baked_confidence.png")
Image.fromarray((np.clip(res2["remaining"], 0, 1) * 255).astype(np.uint8)).save(f"{d}/baked_remaining.png")
print("ALL BAKE INTEGRATION CHECKS PASSED")
