// ComfyUI extension glue for "Texture Painter AI (3D)".
// The editor itself lives in texpaint_editor.bundle.js (Three.js, bundled - no CDN needed).
import { app } from "../../scripts/app.js";
import { api } from "../../scripts/api.js";
import { TexturePaintEditor } from "./texpaint_editor.bundle.js";

const NODE_PAINTER = "TexturePainterAI";
const MIN_WIDGET_H = 640;
const records = new Map(); // node.id -> record
const bySession = new Map(); // session id -> record

const tlog = (...a) => console.log("[TexturePainterAI]", ...a);
const terr = (...a) => console.error("[TexturePainterAI]", ...a);

// ------------------------------------------------------------------------------------------
// helpers
// ------------------------------------------------------------------------------------------
function newSessionId() {
  const r = (crypto.randomUUID ? crypto.randomUUID() : String(Math.random()) + String(Date.now())).replace(/[^A-Za-z0-9]/g, "");
  return "tp_" + r.slice(0, 20);
}

function fnv(str, seed) {
  let h = seed >>> 0;
  for (let i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = Math.imul(h, 16777619) >>> 0; }
  return h.toString(16).padStart(8, "0");
}

async function apiJSON(path, opts) {
  const r = await api.fetchApi(path, opts);
  let j = null;
  try { j = await r.json(); } catch (_) { /* not json */ }
  if (!r.ok) throw new Error(`HTTP ${r.status} from ${path}: ${(j && j.error) || r.statusText}`);
  return j;
}

function hideWidget(w) {
  if (!w) return;
  w.hidden = true;
  w.computeSize = () => [0, -4];
  if (w.element && w.element.style) w.element.style.display = "none";
  if (w.options) w.options.hidden = true;
}

function writeStateWidget(rec) {
  rec.stateW.value = JSON.stringify({ session: rec.sid });
}

function persistUI(rec, state) {
  rec.node.properties = rec.node.properties || {};
  rec.node.properties.texpaint_ui = state;
  try { app.graph && app.graph.setDirtyCanvas && app.graph.setDirtyCanvas(true, true); } catch (_) { /* ignore */ }
}

// ------------------------------------------------------------------------------------------
// server IO
// ------------------------------------------------------------------------------------------
async function uploadModel(rec, file) {
  const fd = new FormData();
  fd.append("file", file, file.name);
  rec.ed.setStatus(`Uploading ${file.name} (${(file.size / 1048576).toFixed(1)} MB) ...`);
  const j = await apiJSON("/texpaint/upload_model", { method: "POST", body: fd });
  rec.ed.log("ok", `Model stored on the server as ${j.name}`);
  return j.name;
}

async function autosave(rec) {
  const ed = rec.ed;
  if (!ed.hasModel || rec.restoring) return;
  const fd = new FormData();
  let any = false;
  if (rec.savedTexVersion !== ed.textureVersion) { fd.append("texture", await ed.exportTextureBlob(), "texture.png"); any = true; }
  if (rec.savedMaskVersion !== ed.maskVersion) { fd.append("uvmask", await ed.exportMaskBlob(), "mask.png"); any = true; }
  if (!any) return;
  const tv = ed.textureVersion, mv = ed.maskVersion;
  try {
    await apiJSON(`/texpaint/put/${rec.sid}`, { method: "POST", body: fd });
    rec.savedTexVersion = tv;
    rec.savedMaskVersion = mv;
  } catch (e) {
    ed.log("warn", "Autosave of the session failed (the workflow will still capture on Queue)", e);
  }
}

function scheduleAutosave(rec) {
  clearTimeout(rec.saveTimer);
  rec.saveTimer = setTimeout(() => autosave(rec).catch((e) => terr("autosave", e)), 2500);
}

/** Captures the current view and stores it on the server. Skips the work when nothing changed. */
async function commitOne(rec, force = false) {
  const ed = rec.ed;
  if (ed.failed) throw new Error("Texture Painter: WebGL2 is not available in this browser.");
  if (!ed.hasModel) return false; // the Python node reports a clear error
  if (rec.restoring) await rec.restoring;
  const cam = [ed.camera.position.toArray(), ed.controls.target.toArray(), ed.camera.fov, ed.ui.pane3d.offsetWidth, ed.ui.pane3d.offsetHeight];
  const key = JSON.stringify([ed.meshHash, ed.textureVersion, ed.maskVersion, cam, ed.state.capture]);
  if (!force && rec.lastKey === key) return true;
  const t0 = performance.now();
  ed.setStatus("Capturing view ...");
  const includeMesh = force || rec.sentMesh !== ed.meshHash;
  const includeTexture = force || rec.sentTex !== ed.textureVersion;
  const out = await ed.capture({ includeMesh, includeTexture });
  const commitId = "c" + fnv(key, 0x811c9dc5) + fnv(key.split("").reverse().join(""), 0x1b873593);
  const fd = new FormData();
  fd.append("commit_id", commitId);
  fd.append("meta", JSON.stringify(out.meta));
  for (const k of ["view", "viewmask", "depth", "normal", "uvmask", "texture", "mesh"]) {
    if (out[k]) fd.append(k, out[k], k === "mesh" ? "mesh.bin" : k + ".png");
  }
  try {
    await apiJSON(`/texpaint/commit/${rec.sid}`, { method: "POST", body: fd });
  } catch (e) {
    ed.log("error", "Could not store the captured view on the server", e);
    ed.setStatus("Capture failed: " + e.message, "err");
    throw e;
  }
  rec.lastKey = key;
  if (includeMesh) rec.sentMesh = ed.meshHash;
  if (includeTexture) { rec.sentTex = ed.textureVersion; rec.savedTexVersion = ed.textureVersion; }
  rec.savedMaskVersion = ed.maskVersion;
  ed.markSynced();
  writeStateWidget(rec);
  const ms = Math.round(performance.now() - t0);
  ed.setStatus(`Captured ${out.meta.view_size[0]}x${out.meta.view_size[1]} view in ${ms} ms.`, "ok");
  ed.log("ok", `Captured view ${out.meta.view_size.join("x")} (commit ${commitId}, ${ms} ms).`);
  return true;
}

async function commitAll(force = false) {
  for (const rec of records.values()) {
    const n = rec.node;
    if (n.mode !== undefined && n.mode !== 0) continue; // muted / bypassed
    await commitOne(rec, force);
  }
}

// ------------------------------------------------------------------------------------------
// restore after a workflow load / page refresh
// ------------------------------------------------------------------------------------------
async function restore(rec) {
  const ed = rec.ed;
  const ui = rec.node.properties && rec.node.properties.texpaint_ui;
  if (!ui) return;
  try {
    ed.applyState(ui);
    if (ui.model && ui.model.name) {
      ed.setStatus("Restoring " + ui.model.name + " ...");
      const r = await api.fetchApi(`/texpaint/model/${encodeURIComponent(ui.model.name)}`);
      if (!r.ok) throw new Error(`Model file "${ui.model.name}" is not on the server any more (HTTP ${r.status}). Load it again.`);
      await ed.loadModelBuffer(await r.arrayBuffer(), ui.model.name, { keepTexture: true });
      const tr = await api.fetchApi(`/texpaint/session/${rec.sid}/texture.png`);
      if (tr.ok) {
        ed.setTextureFromImage(await createImageBitmap(await tr.blob()), { label: "restore", keepHistory: false });
      } else if (ed.info && ed.info.embedded) {
        ed.setTextureFromImage(ed.info.embedded, { label: "model texture", keepHistory: false });
      }
      const mr = await api.fetchApi(`/texpaint/session/${rec.sid}/mask.png`);
      if (mr.ok) ed.importMaskBitmap(await createImageBitmap(await mr.blob()), { undo: false });
      ed.applyState(ui); // camera again (loading the model re-frames it)
      rec.savedTexVersion = ed.textureVersion;
      rec.savedMaskVersion = ed.maskVersion;
      ed.setStatus("Restored " + ui.model.name, "ok");
    }
  } catch (e) {
    ed.log("error", "Restoring the session failed", e);
    ed.setStatus("Restore failed: " + e.message, "err");
  }
}

// ------------------------------------------------------------------------------------------
// node wiring
// ------------------------------------------------------------------------------------------
function setupPainterNode(node) {
  node.properties = node.properties || {};
  const stateW = (node.widgets || []).find((w) => w.name === "state_json");
  hideWidget(stateW);

  const rec = { node, stateW, sid: newSessionId(), lastKey: null, sentMesh: null, sentTex: null, savedTexVersion: null, savedMaskVersion: null, restoring: null };
  records.set(node.id, rec);
  bySession.set(rec.sid, rec);

  const host = document.createElement("div");
  host.style.cssText = "width:100%;height:100%;position:relative;overflow:hidden;pointer-events:auto";
  const ed = new TexturePaintEditor({
    hooks: {
      onState: (s) => persistUI(rec, s),
      onDirty: (kind) => { if (kind === "texture" || kind === "mask" || kind === "model") scheduleAutosave(rec); },
      onModelPicked: (file) => uploadModel(rec, file),
      onSyncRequest: () => commitOne(rec, true).catch((e) => terr("Sync failed", e)),
    },
  });
  rec.ed = ed;
  host.appendChild(ed.root);
  writeStateWidget(rec);

  const w = node.addDOMWidget("texpaint_view", "texpaint_view", host, {
    serialize: false,
    hideOnZoom: false,
    getMinHeight: () => MIN_WIDGET_H,
  });
  w.computeSize = (width) => [width || 760, MIN_WIDGET_H];
  // viewport first, prompt widgets below it
  const i = node.widgets.indexOf(w);
  if (i > 0) { node.widgets.splice(i, 1); node.widgets.unshift(w); }
  const sz = node.size || [0, 0];
  node.setSize([Math.max(sz[0], 980), Math.max(sz[1], MIN_WIDGET_H + 330)]);

  const origRemoved = node.onRemoved;
  node.onRemoved = function () {
    try { clearTimeout(rec.saveTimer); ed.dispose(); } catch (e) { terr("dispose failed", e); }
    records.delete(node.id);
    bySession.delete(rec.sid);
    return origRemoved && origRemoved.apply(this, arguments);
  };
  return rec;
}

async function cloneSession(src, dst) {
  try { await apiJSON("/texpaint/clone", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ src, dst }) }); } catch (e) { tlog("clone session skipped:", e.message); }
}

// debug handle (browser console:  TexturePainterAI.records)
window.TexturePainterAI = { records, bySession, commitAll };

app.registerExtension({
  name: "TexturePainterAI.Editor",

  async beforeRegisterNodeDef(nodeType, nodeData) {
    if (nodeData.name !== NODE_PAINTER) return;

    const onCreated = nodeType.prototype.onNodeCreated;
    nodeType.prototype.onNodeCreated = function () {
      const r = onCreated ? onCreated.apply(this, arguments) : undefined;
      try { setupPainterNode(this); } catch (e) { terr("Could not create the Texture Painter UI", e); }
      return r;
    };

    const onConf = nodeType.prototype.onConfigure;
    nodeType.prototype.onConfigure = function () {
      const r = onConf ? onConf.apply(this, arguments) : undefined;
      const rec = records.get(this.id);
      if (rec) {
        let cloneFrom = null;
        try {
          const saved = JSON.parse((rec.stateW && rec.stateW.value) || "{}");
          if (saved.session && saved.session !== rec.sid) {
            bySession.delete(rec.sid);
            const other = bySession.get(saved.session);
            if (other && other !== rec) { // a copy of another node: give it its own session, copy the files
              cloneFrom = saved.session;
            } else {
              rec.sid = saved.session;
            }
            bySession.set(rec.sid, rec);
            writeStateWidget(rec);
          }
        } catch (e) { terr("bad state_json", e); }
        rec.restoring = (async () => {
          if (cloneFrom) await cloneSession(cloneFrom, rec.sid);
          await restore(rec);
        })().finally(() => { rec.restoring = null; });
      }
      return r;
    };
  },

  async setup() {
    // 1) capture the view automatically right before a prompt is queued
    if (!app.__texpaintWrapped) {
      app.__texpaintWrapped = true;
      const origApp = app.queuePrompt;
      if (typeof origApp === "function") {
        app.queuePrompt = async function () { await commitAll(); return origApp.apply(this, arguments); };
      }
      const origApi = api.queuePrompt;
      if (typeof origApi === "function") {
        api.queuePrompt = async function () { await commitAll(); return origApi.apply(this, arguments); };
      }
    }
    // 2) the Bake node announces its result
    api.addEventListener("texpaint.baked", async (ev) => {
      const d = ev.detail || {};
      const rec = bySession.get(d.session);
      if (!rec) return;
      try {
        const get = async (f) => {
          const r = await api.fetchApi(`/texpaint/session/${d.session}/${f}`);
          if (!r.ok) throw new Error(`HTTP ${r.status} while fetching ${f}`);
          return createImageBitmap(await r.blob());
        };
        const result = await get(d.result);
        const remaining = d.remaining ? await get(d.remaining).catch(() => null) : null;
        rec.ed.showResult(result, remaining, { summary: d.summary, warnings: d.warnings, ...(d.stats || {}) });
      } catch (e) {
        rec.ed.log("error", "Could not load the baked result", e);
        rec.ed.setStatus("Could not load the baked result: " + e.message, "err");
      }
    });
  },
});
