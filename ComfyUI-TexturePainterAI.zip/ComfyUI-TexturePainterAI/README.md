# Texture Painter AI for ComfyUI

Paint a mask on a 3D model (or on its UV map), let **Flux.2 Klein 9B** repaint what is under the mask,
and bake the result back into the model's UV texture - only inside the masked area.

## Install
1. Copy the whole folder `ComfyUI-TexturePainterAI` into `ComfyUI/custom_nodes/`.
2. Start ComfyUI. Missing Python packages (numpy, Pillow, scipy) are installed automatically on start-up
   (`__init__.py` -> `tp_install.py`). Nothing else is needed: the 3D editor is pre-bundled (no npm, no CDN).
3. Hard-refresh the browser (Ctrl+F5). Add nodes via *Add Node -> TexturePainterAI*.

ComfyUI-Manager also picks up `install.py` / `requirements.txt`.

## Wire it up (Klein workflow)
No pre-wired workflow JSON is shipped (it could not be verified here). Start from ComfyUI's template
**"Flux.2 [Klein] 9B: Image Edit"** and change two things:
- replace *Load Image* with the painter's `edit_image` output (prompt -> the text-encode node),
- replace *Save Image* with **Texture Painter AI - Bake**: `bake_data` <- painter, `generated_image` <- sampler/decoder output.

Optionally connect `width`/`height` to the latent size. Press **Queue**: the view is captured automatically,
Klein edits it, Bake projects it into UV space, and the result appears in the editor.
Review it (compare toggle in the banner), then **Apply** or **Discard**. Every apply is stored in the texture history (revert any time).

## Using the editor
- Load a model (obj / glb / gltf / fbx) or drag & drop it; load or create a texture (UV map must be unwrapped, 0-1).
- **Brush / Erase** (B / E): size, hardness, softness, opacity, spacing, stabiliser, pen pressure.
- Mask tools: clear, fill, invert, grow, shrink, feather, import/export PNG. The mask lives in UV space, so it is mirrored in the UV pane.
- Dashed frame = exactly what is sent to the generator (aspect, size, shading, background, min facing).
- Orange overlay = masked area seen at a grazing angle (poor bake from this view; rotate and repeat).
- Shortcuts: B/E brush/erase, N orbit, X swap, [ ] size, Ctrl+Z / Ctrl+Y, F frame mask, Home frame model, M mask overlay, 1-3 layouts, Space = temporary orbit, Esc.

## What v1 does not do (roadmap)
Blend-mode layers (history/revert is provided instead), symmetry painting, multi-view generation in one run,
normal/roughness channels. Bake quality depends on the view: do one angle at a time.

## Troubleshooting
- Errors appear in the node's **Log** panel and, with full tracebacks, in the ComfyUI console. Please copy those when reporting a problem.
- Do not edit the hidden `state_json` widget; it only holds the session id.
- Uploads are limited to 100 MB. Files are stored in `ComfyUI/input/texpaint/`.
- WebGL2 is required (any current Chrome/Edge/Firefox).
- `preview.html` is a standalone UI demo (generation simulated); open it by double-click.
- Rebuild the frontend (optional): `npm i && npm run build` (sources in `src/`).
