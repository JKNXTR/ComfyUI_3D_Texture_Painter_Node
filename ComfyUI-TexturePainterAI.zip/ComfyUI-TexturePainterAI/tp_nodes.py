"""ComfyUI nodes: Texture Painter AI (3D UI + render passes) and Texture Painter AI - Bake."""
import json
import os
import re
import time
import uuid

import numpy as np
from PIL import Image, ImageFilter

from . import tp_common as C
from . import tp_core as core

CATEGORY = "TexturePainterAI"
BAKE_TYPE = "TEXPAINT_BAKE"


# -------------------------------------------------------------------------------------------
# small helpers
# -------------------------------------------------------------------------------------------
def _to_tensor(arr):
    import torch
    return torch.from_numpy(np.ascontiguousarray(arr))


def _to_numpy(t):
    if hasattr(t, "detach"):
        t = t.detach().cpu().numpy()
    return np.asarray(t)


def _load_png(path, mode="RGB"):
    with Image.open(path) as im:
        return np.array(im.convert(mode))


def _parse_state(state_json):
    try:
        s = json.loads(state_json or "{}")
        return s if isinstance(s, dict) else {}
    except Exception:
        return {}


def _read_commit(sdir):
    return C.read_json(os.path.join(sdir, "commit.json"))


def _hex_rgb(h, default=(255, 0, 255)):
    m = re.match(r"^#?([0-9a-fA-F]{6})$", (h or "").strip())
    if not m:
        return default
    n = int(m.group(1), 16)
    return ((n >> 16) & 255, (n >> 8) & 255, n & 255)


_COLOR_NAMES = {(255, 0, 255): "magenta", (255, 0, 0): "red", (0, 255, 0): "green", (0, 0, 255): "blue",
                (255, 255, 0): "yellow", (0, 255, 255): "cyan", (255, 128, 0): "orange", (255, 255, 255): "white"}


def _grow_feather(m, grow, feather):
    """m float32 (H,W) 0..1 -> grown + feathered mask."""
    if grow > 0:
        if core._ndi is not None:
            m = core._ndi.maximum_filter(m, size=2 * int(grow) + 1)
        else:
            im = Image.fromarray((np.clip(m, 0, 1) * 255).astype(np.uint8))
            for _ in range(int(grow)):
                im = im.filter(ImageFilter.MaxFilter(3))
            m = np.asarray(im).astype(np.float32) / 255.0
    if feather > 0:
        im = Image.fromarray((np.clip(m, 0, 1) * 255).astype(np.uint8)).filter(ImageFilter.GaussianBlur(float(feather)))
        m = np.asarray(im).astype(np.float32) / 255.0
    return np.clip(m, 0, 1).astype(np.float32)


# -------------------------------------------------------------------------------------------
# Node 1: the painter
# -------------------------------------------------------------------------------------------
class TexturePainterAI:
    CATEGORY = CATEGORY
    FUNCTION = "run"
    RETURN_TYPES = ("IMAGE", "IMAGE", "MASK", "IMAGE", "IMAGE", "IMAGE", "MASK", "STRING", "INT", "INT", BAKE_TYPE)
    RETURN_NAMES = ("edit_image", "view_image", "view_mask", "depth", "normal", "uv_texture", "uv_mask",
                    "prompt", "width", "height", "bake_data")
    DESCRIPTION = ("3D texture painter: load a UV-unwrapped model, paint a mask on it, and send the camera view + mask "
                   "to any image-edit workflow (e.g. FLUX.2 Klein). Connect the result to 'Texture Painter AI - Bake'.")

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "state_json": ("STRING", {"default": "{}", "multiline": False}),
                "prompt": ("STRING", {"default": "", "multiline": True,
                                      "tooltip": "Short description of what should be painted in the masked area."}),
                "style_hint": ("STRING", {"default": "flat albedo texture, no lighting, no shadows, no reflections, natural detail",
                                          "multiline": True,
                                          "tooltip": "Appended to the prompt. Keeps lighting out of the texture."}),
                "compose_prompt": ("BOOLEAN", {"default": True,
                                               "tooltip": "Wrap the prompt in an instruction that refers to the marked area."}),
                "mask_hint": (["tint_color", "gray_fill", "none"], {"default": "tint_color",
                                                                    "tooltip": "How the masked area is marked in edit_image."}),
                "hint_color": ("STRING", {"default": "#ff00ff"}),
                "hint_strength": ("FLOAT", {"default": 1.0, "min": 0.0, "max": 1.0, "step": 0.05}),
                "mask_grow": ("INT", {"default": 6, "min": 0, "max": 128, "tooltip": "Grow the view mask (pixels)."}),
                "mask_feather": ("INT", {"default": 4, "min": 0, "max": 64, "tooltip": "Blur the view mask edge (pixels)."}),
            }
        }

    @classmethod
    def IS_CHANGED(cls, state_json="{}", **kwargs):
        try:
            sid = _parse_state(state_json).get("session")
            c = _read_commit(C.session_dir(sid))
            return (c or {}).get("commit_id", "no-commit") + f":{kwargs.get('mask_grow')}:{kwargs.get('mask_feather')}"
        except Exception:
            return "invalid"

    def run(self, state_json, prompt, style_hint, compose_prompt, mask_hint, hint_color, hint_strength,
            mask_grow, mask_feather):
        try:
            return self._run(state_json, prompt, style_hint, compose_prompt, mask_hint, hint_color, hint_strength,
                             mask_grow, mask_feather)
        except Exception as e:
            C.log_exc("Texture Painter AI failed")
            raise RuntimeError(f"{C.PREFIX} {type(e).__name__}: {e}  (full traceback is in the ComfyUI console)") from e

    def _run(self, state_json, prompt, style_hint, compose_prompt, mask_hint, hint_color, hint_strength,
             mask_grow, mask_feather):
        state = _parse_state(state_json)
        sid = state.get("session")
        if not sid:
            raise ValueError("The node has no session yet. Open the node, load a model and press 'Sync'.")
        sdir = C.session_dir(sid)
        commit = _read_commit(sdir)
        need = ["view.png", "viewmask.png", "depth.png", "normal.png", "mask.png", "texture.png", "mesh.bin", "camera.json"]
        missing = [f for f in need if not os.path.isfile(os.path.join(sdir, f))]
        if not commit or missing:
            raise FileNotFoundError(
                "No captured view found for this node (" + (", ".join(missing) if missing else "no commit") + "). "
                "Load a model in the Texture Painter node and press 'Sync' (or just Queue again - the view is captured automatically).")
        meta = C.read_json(os.path.join(sdir, "camera.json"), {})
        view = _load_png(os.path.join(sdir, "view.png")).astype(np.float32) / 255.0
        vmask = _load_png(os.path.join(sdir, "viewmask.png"), "L").astype(np.float32) / 255.0
        depth = _load_png(os.path.join(sdir, "depth.png")).astype(np.float32) / 255.0
        normal = _load_png(os.path.join(sdir, "normal.png")).astype(np.float32) / 255.0
        tex = _load_png(os.path.join(sdir, "texture.png")).astype(np.float32) / 255.0
        umask = _load_png(os.path.join(sdir, "mask.png"), "L").astype(np.float32) / 255.0
        if umask.shape != tex.shape[:2]:  # keep uv_mask and uv_texture the same size
            umask = np.asarray(Image.fromarray((umask * 255).astype(np.uint8)).resize((tex.shape[1], tex.shape[0]), Image.BILINEAR)).astype(np.float32) / 255.0
        H, W = view.shape[:2]

        if float(vmask.max()) < 0.01:
            C.LOG.warning("%s The painted mask is not visible from the current camera - the edit will change nothing.", C.PREFIX)

        vm = _grow_feather(vmask, int(mask_grow), int(mask_feather))
        edit = view.copy()
        if mask_hint != "none":
            col = np.array(_hex_rgb(hint_color), np.float32) / 255.0 if mask_hint == "tint_color" else np.full(3, 0.5, np.float32)
            a = (vm * float(hint_strength))[..., None]
            edit = view * (1.0 - a) + col[None, None, :] * a

        p = (prompt or "").strip()
        style = (style_hint or "").strip().strip(".")
        if compose_prompt:
            if mask_hint == "none":
                text = f"{p}. {style}." if style else f"{p}."
            else:
                name = "gray" if mask_hint == "gray_fill" else _COLOR_NAMES.get(_hex_rgb(hint_color), "highlighted")
                text = f"Repaint only the {name} marked area: {p}."
                if style:
                    text += f" {style}."
                text += " Keep everything outside the marked area exactly unchanged."
        else:
            text = p

        bake_data = {
            "session": sid,
            "dir": sdir,
            "commit_id": commit["commit_id"],
            "view_size": [int(W), int(H)],
            "facing": float(meta.get("facing", 0.25)),
            "tex_size": [int(tex.shape[1]), int(tex.shape[0])],
        }
        t = _to_tensor
        return (
            t(edit[None]), t(view[None]), t(vm[None]), t(depth[None]), t(normal[None]),
            t(tex[None]), t(umask[None]), text, int(W), int(H), bake_data,
        )


# -------------------------------------------------------------------------------------------
# Node 2: the baker
# -------------------------------------------------------------------------------------------
class TexturePainterAIBake:
    CATEGORY = CATEGORY
    FUNCTION = "run"
    OUTPUT_NODE = True
    RETURN_TYPES = ("IMAGE", "MASK", "MASK", "STRING")
    RETURN_NAMES = ("texture", "bake_confidence", "remaining_mask", "report")
    DESCRIPTION = ("Projects the generated image back onto the UV texture (occlusion + angle aware) inside the painted mask "
                   "and sends the result to the Texture Painter viewport.")

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "bake_data": (BAKE_TYPE,),
                "generated_image": ("IMAGE", {"tooltip": "The edited view. Must have the same framing as edit_image."}),
                "facing_override": ("FLOAT", {"default": -1.0, "min": -1.0, "max": 0.95, "step": 0.01,
                                              "tooltip": "-1 = use the 'Min facing' value from the painter node."}),
                "depth_bias": ("FLOAT", {"default": 0.003, "min": 0.0, "max": 0.05, "step": 0.0005,
                                         "tooltip": "Raise when visible texels are wrongly treated as occluded."}),
                "strength": ("FLOAT", {"default": 1.0, "min": 0.0, "max": 1.0, "step": 0.01}),
                "padding": ("INT", {"default": 8, "min": 0, "max": 64, "tooltip": "Texels spread over UV island borders to hide seams."}),
            }
        }

    @classmethod
    def IS_CHANGED(cls, **kwargs):
        return float("nan")  # always re-bake when the graph is queued

    def run(self, bake_data, generated_image, facing_override, depth_bias, strength, padding):
        try:
            return self._run(bake_data, generated_image, facing_override, depth_bias, strength, padding)
        except Exception as e:
            C.log_exc("Texture Painter AI Bake failed")
            raise RuntimeError(f"{C.PREFIX} {type(e).__name__}: {e}  (full traceback is in the ComfyUI console)") from e

    def _run(self, bake_data, generated_image, facing_override, depth_bias, strength, padding):
        t0 = time.time()
        sid = bake_data["session"]
        sdir = C.session_dir(sid)
        commit = _read_commit(sdir)
        if not commit or commit.get("commit_id") != bake_data["commit_id"]:
            raise RuntimeError("The view in the Texture Painter changed after this generation was started. "
                               "Queue the workflow again so the generated image matches the captured view.")
        meta = C.read_json(os.path.join(sdir, "camera.json"))
        with open(os.path.join(sdir, "mesh.bin"), "rb") as f:
            mesh = core.read_mesh_bin(f.read())
        if meta.get("mesh_hash") and mesh.hash and meta["mesh_hash"] != mesh.hash:
            raise RuntimeError("mesh.bin does not match the captured camera data (mesh hash mismatch). Press 'Sync' in the painter node.")
        tex = _load_png(os.path.join(sdir, "texture.png"))
        H, W = tex.shape[:2]
        umask = _load_png(os.path.join(sdir, "mask.png"), "L").astype(np.float32) / 255.0
        if umask.shape != (H, W):
            umask = np.asarray(Image.fromarray((umask * 255).astype(np.uint8)).resize((W, H), Image.BILINEAR)).astype(np.float32) / 255.0
        depth = _load_png(os.path.join(sdir, "depth.png"))

        g = _to_numpy(generated_image)
        if g.ndim == 4:
            if g.shape[0] > 1:
                C.LOG.warning("%s generated_image has %d images - only the first is used.", C.PREFIX, g.shape[0])
            g = g[0]
        g = np.clip(g[..., :3].astype(np.float32), 0.0, 1.0) * 255.0
        gh, gw = g.shape[:2]
        vw, vh = bake_data["view_size"]
        warnings = []
        if abs(gw / gh - vw / vh) > 0.02:
            warnings.append(f"Generated image is {gw}x{gh} but the captured view is {vw}x{vh} (different aspect ratio) - "
                            "the projection will be misaligned. Use the width/height outputs of the painter node for the latent size.")

        t1 = time.time()
        raster = core.get_raster(mesh, W, H)
        t_raster = time.time() - t1
        if raster.overlap_ratio > 0.01:
            warnings.append(f"{raster.overlap_ratio * 100:.1f}% of the UV texels are covered by overlapping UV islands - "
                            "overlapping/mirrored UVs get painted on both sides.")
        facing = float(facing_override) if facing_override >= 0 else float(bake_data.get("facing", 0.25))
        res = core.bake(mesh, raster, meta["camera"], depth, g, umask, tex, facing=facing,
                        depth_bias=float(depth_bias), strength=float(strength), padding=int(padding))
        st = res["stats"]
        if st["masked"] == 0:
            warnings.append("The UV mask is empty - nothing was painted. Paint a mask in the Texture Painter first.")
        elif st["baked"] == 0:
            warnings.append("The masked area is not visible from the captured camera (hidden or at a grazing angle).")
        summary = (f"Baked {st['coverage'] * 100:.0f}% of the masked texels ({st['baked']:,}/{st['masked']:,}); "
                   f"occluded {st['occluded']:,}, grazing {st['grazing']:,}, outside view {st['outside']:,}.")
        if 0 < st["coverage"] < 0.9:
            summary += " The rest stays masked - rotate the camera and run again."

        rid = uuid.uuid4().hex[:10]
        fname, rname = f"result_{rid}.png", f"remaining_{rid}.png"
        Image.fromarray(res["texture"]).save(os.path.join(sdir, fname), compress_level=3)
        Image.fromarray((np.clip(res["remaining"], 0, 1) * 255).astype(np.uint8)).save(os.path.join(sdir, rname), compress_level=3)
        self._prune(sdir)

        report = f"{summary} (raster {t_raster:.1f}s, total {time.time() - t0:.1f}s)"
        for w in warnings:
            report += "\nWARNING: " + w
        print(f"{C.PREFIX} {report}", flush=True)
        payload = {"session": sid, "commit_id": bake_data["commit_id"], "result": fname, "remaining": rname,
                   "summary": summary, "warnings": warnings, "stats": {k: (float(v) if isinstance(v, float) else int(v)) for k, v in st.items()}}
        try:
            from server import PromptServer
            PromptServer.instance.send_sync("texpaint.baked", payload)
        except Exception:
            C.log_exc("Could not notify the web UI (the result files were still written)")

        t = _to_tensor
        return (t(res["texture"].astype(np.float32)[None] / 255.0), t(np.clip(res["confidence"], 0, 1)[None]),
                t(res["remaining"][None]), report)

    @staticmethod
    def _prune(sdir, keep=6):
        try:
            files = sorted((f for f in os.listdir(sdir) if C.RESULT_RE.match(f)), key=lambda f: os.path.getmtime(os.path.join(sdir, f)), reverse=True)
            for f in files[keep * 2:]:
                os.remove(os.path.join(sdir, f))
        except Exception:
            C.log_exc("Could not prune old results")


NODE_CLASS_MAPPINGS = {
    "TexturePainterAI": TexturePainterAI,
    "TexturePainterAIBake": TexturePainterAIBake,
}
NODE_DISPLAY_NAME_MAPPINGS = {
    "TexturePainterAI": "Texture Painter AI (3D)",
    "TexturePainterAIBake": "Texture Painter AI - Bake",
}
